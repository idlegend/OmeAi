const withMT = require("@material-tailwind/react/utils/withMT");

module.exports = withMT({
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: "#201AFF",
        secondary: "#A4A2FE",
        tGrey: "#556061",
        tGreyDark: "#737373",
        darkBg: "#1D1D1F",
        gray2: "#ABB3B7",
      },
      fontFamily: {
        sans: ["Open Sans", "sans-serif"],
      },
      backgroundImage: {
        "light-pattern": "url('/light_pattern.png')",
        "light-pattern-light": "url('/light_pattern_l.png')",
        howitworks_bg: "url('/how_it_works.svg')",
        howitworksM_bg: "url('/how_it_works_m.svg')",
        features_bg: "url('/features_bg.png')",
      },
      animation: {
        "spin-slow": "spin 15s linear infinite",
      },
    },
  },
  plugins: [],
});
