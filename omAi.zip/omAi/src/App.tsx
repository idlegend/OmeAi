import { Routes, Route } from "react-router";
import { Login, SignUp } from "./pages/auth";
import { ProtectedRoute, Dashboard } from "./layouts";
import axios from "axios";
import { routes } from "./routes";
import { Navigate } from "react-router";
import DeleteAccount from "./pages/delete-account";
import { OmeifeTerms, DigitalLiteracyTerms } from "./pages/terms";
import { OmefieAiPolicy, DigitalLiteracyPolicy } from "./pages/policies";
import { FAQ } from "./pages";
import { useEffect } from "react";
import Layout from "./layouts/layout";
import HomePage from "./pages/landing/home";
import Features from "./pages/landing/features";
import Pricing from "./pages/landing/pricing";
import AboutUs from "./pages/landing/about";
import Contact from "./pages/landing/contact";
import UpdatePassword from "./pages/auth/update-password";
import ForgotPassword from "./pages/auth/forgot-password";
axios.defaults.baseURL = "https://apis.omeife.ai/api/v1";
axios.interceptors.request.use(function (config) {
  const token = sessionStorage.getItem("auth_token");
  config.headers.Authorization = token ? `Bearer ${token}` : "";
  return config;
});

function App() {
  useEffect(() => {
    if (
      localStorage.theme === "dark" ||
      (!("theme" in localStorage) &&
        window.matchMedia("(prefers-color-scheme: dark)").matches)
    ) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, []);

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="home" element={<HomePage />} />
        <Route path="features" element={<Features />} />
        <Route path="pricing" element={<Pricing />} />
        <Route path="about-us" element={<AboutUs />} />
        <Route path="contact-us" element={<Contact />} />
        <Route path="signUp" element={<SignUp />} />
        <Route path="signin" element={<Login />} />
        <Route path="Update-password" element={<UpdatePassword />} />
        <Route path="forgot-password" element={<ForgotPassword />} />
        <Route path="delete-account" element={<DeleteAccount />} />
        <Route path="legal/terms-omeifeAi" element={<OmeifeTerms />} />
        <Route path="legal/policies-omeifeAi" element={<OmefieAiPolicy />} />
        <Route path="faq" element={<FAQ />} />
      </Route>

      <Route
        path="legal/terms-digital-literacy"
        element={<DigitalLiteracyTerms />}
      />
      <Route
        path="legal/policies-digital-literacy"
        element={<DigitalLiteracyPolicy />}
      />
      <Route element={<ProtectedRoute />}>
        <Route element={<Dashboard />}>
          {routes.map((route, i) => {
            if (route.subpages) {
              return route.subpages.map((subpage, i) => (
                <Route key={i} path={route.path} element={route.element}>
                  <Route
                    key={i}
                    path={`${route.path}${subpage.path}`}
                    element={subpage.element}
                  />
                </Route>
              ));
            }
            return <Route key={i} path={route.path} element={route.element} />;
          })}
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/home" />} />
    </Routes>
  );
}

export default App;
