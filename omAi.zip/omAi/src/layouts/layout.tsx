import { Outlet, useNavigate } from "react-router-dom";
import Header from "../components/Layout/Header";
import Footer from "../components/Layout/Footer";
import { Icon } from "@iconify/react";
import Button from "../components/common/Button";
import { useEffect, useState } from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const links = [
  {
    name: "Home",
    route: "",
  },
  {
    name: "Features",
    route: "features",
  },
  {
    name: "Pricing",
    route: "pricing",
  },
  {
    name: "About Us",
    route: "about-us",
  },
  {
    name: "Contact Us",
    route: "contact-us",
  },
];

export const Layout = () => {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    const body = document?.getElementById("root");

    if (!body) {
      return;
    }

    if (showMenu) {
      body.style.overflow = "hidden";
    } else {
      body.style.overflow = "auto";
    }
  }, [showMenu]);

  const handleResize = () => {
    if (window.screen.width >= 1280) {
      setShowMenu(false);
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="h-full w-full max-w-screen !overflow-x-hidden md:!overflow-x-clip min-h-screen theme ">
      <ToastContainer />
      <Header setShowMenu={setShowMenu} />
      <Outlet />
      <Footer />
      {showMenu && (
        <div className="w-full h-full fixed top-0 z-[9999] right-0 bottom-0 flex justify-end left-0 bg-black/10 backdrop-blur-[1px] ">
          <div className="w-[70%] h-[488px] bg-[#8F8CFF] rounded-l-[20px] ">
            <div className="w-full flex justify-end p-3">
              <Icon
                icon="octicon:x-24"
                className="!text-2xl"
                onClick={() => setShowMenu(false)}
              />
            </div>
            <div className="px-5  flex flex-col w-full items-center gap-y-20">
              <ul className="flex w-full flex-col gap-y-5">
                {links.map((link, i) => (
                  <li
                    key={i}
                    onClick={() => {
                      navigate(`/${link.route}`);
                      setShowMenu(false);
                    }}
                    className="text-white text-base"
                  >
                    {link.name}
                  </li>
                ))}
              </ul>

              <Button
                text="Login"
                action={() => {
                  navigate("/signin");
                  setShowMenu(false);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Layout;
