export const PermittedRoutes = () => {
  return <div>PermittedRoutes</div>;
};
