import { Outlet } from "react-router-dom";
import { Modal, Sidebar } from "../components";
import { Header } from "../components/header";
import { useAppDispatch } from "../utils/store";
import { toggleSidebar } from "../utils/features/userSlice";
import { useState, useEffect } from "react";

export const Dashboard = () => {
  const dispatch = useAppDispatch();
  const [theme, setTheme] = useState("dark");

  useEffect(() => {
    setTheme("dark");
  }, []);

  useEffect(() => {
    if (theme == "dark") {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [theme]);
  return (
    <div className="flex h-[100vh] ">
      <Modal />
      <Sidebar theme={theme} setTheme={setTheme} />
      <div
        onClick={() => dispatch(toggleSidebar("close"))}
        className="flex-[4] overflow-auto theme"
      >
        <div className="grid grid-cols-4 2xl:grid-cols-5 p-3 gap-3 xl:p-6 xl:gap-4 relative">
          <Header theme={theme} />
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
