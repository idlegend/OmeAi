import { useEffect, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { User } from "../interfaces";
import { setUser } from "../utils/features/userSlice";
import { useAppDispatch } from "../utils/store";
import Loader from "../components/loader";

export const ProtectedRoute = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const [loading, setLoading] = useState(true);
  const userString = sessionStorage.getItem("user");
  const userToken = sessionStorage.getItem("auth_token");
  const user: User = userString ? JSON.parse(userString) : null;
  const token: string | null = userToken ? userToken : null;

  useEffect(() => {
    if (!user) {
      navigate("signin");
      sessionStorage.clear();
    }
    dispatch(setUser({ user, token }));
    setLoading(false);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
