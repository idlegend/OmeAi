import {
  Home,
  DigitalAssistant,
  Developer,
  Translation,
  SubtitleTranslation,
  Generation,
  TranslationSuccess,
  GenerationSuccess,
  SubtitleTranslationSuccess,
  DigitalLiteracy,
  Profile,
  TextToSpeech,
  TextToSpeechSucess,
  HelpAndSupport
} from "./pages";
import {
  AiDashboardIcon,
  AssistantIcon,
  TranslateIcon,
  DeveloperIcon,
  subtitleTranslateInActive,
  subtitleTranslateActive,
  generationActive,
  generationInActive,
  LiteracyIcon,
  ProfileIcon,
  TextToSpeechIcon,
  HelpAndSupportIcon,
  AboutUsIcon
} from "./assets/icons";

export const routes = [
  {
    icon: AiDashboardIcon,
    name: "Dashboard",
    path: "/dashboard",
    element: <Home />,
  },
  {
    icon: AssistantIcon,
    name: "Knowledge Assistant",
    path: "/assistant",
    permisson: "student",
    element: <DigitalAssistant />,
  },
  {
    icon: LiteracyIcon,
    name: "Digital Literacy",
    path: "/digital-literacy",
    permisson: "student",
    element: <DigitalLiteracy />,
  },
  {
    icon: TranslateIcon,
    name: "Translate",
    path: "/translate",
    permisson: "student",
    element: <Translation />,
    subpages: [
      {
        name: "Translation Success",
        path: "/success",
        element: <TranslationSuccess />,
      },
    ],
  },
  {
    icon: "",
    active: subtitleTranslateActive,
    inActive: subtitleTranslateInActive,
    name: "Subtitle Translation",
    path: "/subtitle-translation",
    permisson: "student",
    element: <SubtitleTranslation />,
    subpages: [
      {
        name: "Subtitle Translation Success",
        path: "/success",
        element: <SubtitleTranslationSuccess />,
      },
    ],
  },
  {
    icon: "",
    active: generationActive,
    inActive: generationInActive,
    name: "Subtitle Generation",
    path: "/subtitle-generation",
    permisson: "student",
    element: <Generation />,
    subpages: [
      {
        name: "Subtitle Generation Success",
        path: "/success",
        element: <GenerationSuccess />,
      },
    ],
  },
  {
    icon: DeveloperIcon,
    name: "Developer",
    path: "/developer",
    permisson: "student",
    element: <Developer />,
  },
  {
    icon: ProfileIcon,
    name: "Profile",
    path: "/profile",
    permisson: "student",
    element: <Profile />,
  },
  {
    icon: TextToSpeechIcon,
    name: "Text To Speech",
    path: "/text-to-speech",
    permisson: "student",
    element:  <TextToSpeech />,
    subpages: [
      {
        name: "Text to speech Success",
        path: "/success",
        element: <TextToSpeechSucess />,
      },
    ],
  },
  {
    icon: HelpAndSupportIcon,
    name: "Help & Support",
    path: "/help-and-support",
    permisson: "student",
    element: <HelpAndSupport />,
  },
  {
    icon: AboutUsIcon,
    name: "About Us",
    path: "/about-us",
    permisson: "student",
    element: <Profile />,
  }
];
