export const status = ['pending', 'approved', 'blocked'];
