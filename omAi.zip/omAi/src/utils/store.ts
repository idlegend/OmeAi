import { configureStore } from "@reduxjs/toolkit";
import {
  userSlice,
  assistantSlice,
  translateSlice,
  subtitleTranslationSlice,
  subtitleGenerationSlice,
  literacySlice,
  profileSlice,
} from "./features";
import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";

export const store = configureStore({
  reducer: {
    user: userSlice,
    assistant: assistantSlice,
    literacy: literacySlice,
    translate: translateSlice,
    substitleTranslate: subtitleTranslationSlice,
    subtitleGeneration: subtitleGenerationSlice,
    profile: profileSlice,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export const useAppDispatch: () => typeof store.dispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
