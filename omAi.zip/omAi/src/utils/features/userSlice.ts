import {
  PayloadAction,
  createAsyncThunk,
  createSlice,
  isAnyOf,
} from "@reduxjs/toolkit";
import { InitialUserState, User } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialUserState: InitialUserState = {
  user: {
    id: 0,
    first_name: "",
    last_name: "",
    phone_number: "",
    email: "",
    imageUrl: "",
    roles: [],
  },
  message: "",
  otpSent: false,
  sidebar: "close",
  loading: false,
  success: false,
  error: {
    default: "An error occurred, try again...",
    errorString: "",
  },
};

export const signUp = createAsyncThunk(
  "signUp",
  async (
    data: {
      email: string;
      first_name: string;
      last_name: string;
      phone_number: string;
      password: string;
      password_confirmation: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const res = await axios.post("/user/register", data);
      return res.data.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const signIn = createAsyncThunk(
  "signIn",
  async (
    data: {
      email: string;
      password: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const res = await axios.post("/user/login", data);
      return res.data.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const updatePassword = createAsyncThunk(
  "updatePassword",
  async (
    data: {
      email: string;
      password: string;
      password_confirmation: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const res = await axios.post("/user/updatePassword", data);
      return res.data.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const forgotPassword = createAsyncThunk(
  "forgotPassword",
  async (
    data: {
      email: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const res = await axios.post("/user/sendVerificationCode", data);
      return res.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const verifyOtp = createAsyncThunk(
  "verifyOtp",
  async (data: string, { rejectWithValue }) => {
    const formData = new FormData();
    formData.append("code", data);
    try {
      const res = await axios.post("/user/verifyUser", formData);
      return res.data.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);


export const verifyCode = createAsyncThunk(
  "verifyCode",
  async ({ OTP, email }: { OTP: string; email: string }, { rejectWithValue }) => {
    const formData = new FormData();
    formData.append("code", OTP);
    formData.append("email", email);
    try {
      const res = await axios.post("/user/verifyCode", formData);
      return res.data;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);


export const resendOtp = createAsyncThunk(
  "resendOtp",
  async (data: string, { rejectWithValue }) => {
    const formData = new FormData();
    if (data) {
      formData.append("email", data);
    } else {
      const data = JSON.parse(sessionStorage.getItem("user")).email;
      formData.append("email", data);
    }
    try {
      const res = await axios.post("/user/sendVerificationCode", formData);
      return res.data.message;
    } catch (err) {
      const axError = err as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const userSlice = createSlice({
  name: "user",
  initialState: initialUserState,
  reducers: {
    clearSuccess: (state) => {
      state.success = false;
      state.otpSent = false;
      state.message = "";
    },
    toggleSidebar: (state, action: PayloadAction<string>) => {
      state.sidebar = action.payload;
    },
    setUser: (state, action: PayloadAction<{ user: User; token: string }>) => {
      sessionStorage.setItem("user", JSON.stringify(action.payload.user));
      return { ...state, user: action.payload.user };
    },
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        isAnyOf(
          signIn.pending,
          signUp.pending,
          verifyOtp.pending,
          resendOtp.pending,
          forgotPassword.pending,
          verifyCode.pending,
          updatePassword.pending,
        ),
        (state, action) => {
          if (action.type == "resendOtp/pending") {
            state.loading = true;
            state.error = { ...state.error, errorString: "" };
            state.success = false;
          } else {
            state.loading = true;
            state.error = { ...state.error, errorString: "" };
            state.success = false;
            state.otpSent = false;
          }
        }
      )
      .addMatcher(
        isAnyOf(
          signIn.fulfilled,
          signUp.fulfilled,
          verifyOtp.fulfilled,
          resendOtp.fulfilled,
          forgotPassword.fulfilled,
          verifyCode.fulfilled,
          updatePassword.fulfilled
        ),
        (state, action) => {
          switch (action.type) {
            case "signUp/fulfilled":
              state.error = { ...state.error, errorString: "" };
              state.message = "Check your email for an OTP";
              sessionStorage.setItem(
                "user",
                JSON.stringify(action.payload.user)
              );
              sessionStorage.setItem("auth_token", action.payload.token);
              state.loading = false;
              state.otpSent = true;
              break;
            case "verifyOtp/fulfilled":
              sessionStorage.setItem(
                "user",
                JSON.stringify(action.payload.user)
              );
              sessionStorage.setItem("auth_token", action.payload.token);
              state.user = action.payload;
              state.error = { ...state.error, errorString: "" };
              state.success = true;
              state.loading = false;
              break;
            case "resendOtp/fulfilled":
              state.error = { ...state.error, errorString: "" };
              state.message = action.payload;
              state.loading = false;
              state.otpSent = true;
              break;
            case "signIn/fulfilled":
              sessionStorage.setItem(
                "user",
                JSON.stringify(action.payload.user)
              );
              sessionStorage.setItem("auth_token", action.payload.token);
              state.user = action.payload;
              state.error = { ...state.error, errorString: "" };
              state.success = true;
              state.loading = false;
              break;
              case "forgotPassword/fulfilled":
                state.error = { ...state.error, errorString: "" };
                state.message = "Check your email for an OTP";
                sessionStorage.setItem(
                  "user",
                  JSON.stringify(action.payload.user)
                );
                sessionStorage.setItem("auth_token", action.payload.token);
                state.loading = false;
                state.otpSent = true;
                break;
                case "verifyCode/fulfilled":
                  state.error = { ...state.error, errorString: "" };
                  sessionStorage.setItem(
                    "user",
                    JSON.stringify(action.payload.user)
                  );
                  sessionStorage.setItem("auth_token", action.payload.token);
                  state.loading = false;
                  state.success = true;
                  break;
                  case "updatePassword/fulfilled":
                    state.error = { ...state.error, errorString: "" };
                    sessionStorage.setItem(
                      "user",
                      JSON.stringify(action.payload.user)
                    );
                    sessionStorage.setItem("auth_token", action.payload.token);
                    state.loading = false;
                    state.success = true;
                    break;
            default:
              state.success = false;
              state.loading = false;
              state.otpSent = false;
              break;
          }
        }
      )
      .addMatcher(
        isAnyOf(
          signIn.rejected,
          signUp.rejected,
          verifyOtp.rejected,
          resendOtp.rejected,
          forgotPassword.rejected,
          verifyCode.rejected,
          updatePassword.rejected
        ),
        (state, action: any) => {
          console.log("error:", action.payload.message);
          if (action.payload.token)
            sessionStorage.setItem("auth_token", action.payload.token);
          state.otpSent = false;
          state.loading = false;
          state.error = { ...state.error, errorString: action.payload.message };
          state.success = false;
        }
      );
  },
});

export const { setUser, toggleSidebar, clearSuccess } = userSlice.actions;
// export const selectUser = (state: RootState) => state.user;
export default userSlice.reducer;
