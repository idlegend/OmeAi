import { PayloadAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  ConfirmModal,
  InitialProfileState,
  ProfileFormState,
} from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: InitialProfileState = {
  confirmModal: { content: "", show: false },
  success: false,
  loading: false,
  deleteLoading: false,
  user: {
    id: 0,
    first_name: "",
    last_name: "",
    phone_number: "",
    email: "",
    imageUrl: "",
    roles: [],
  },
  message: "",
  error: {
    default: "An error occurred, try again...",
    errorString: "",
  },
};

export const updateUserProfile = createAsyncThunk(
  "updateUserProfile",
  async (data: ProfileFormState, { rejectWithValue }) => {
    const formData = new FormData();
    for (const key in data) {
      formData.append(key, data[key]);
    }
    try {
      const res = await axios.post("/user/updateProfile", formData);
      return res.data;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const deleteUserAccount = createAsyncThunk(
  "deleteUserAccount",
  async (data: { email: string; message: string }, { rejectWithValue }) => {
    try {
      const res = await axios.post("/user/delete-account", data);
      return res.data.message;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const profileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {
    resetMessage: (state) => {
      return { ...state, message: "", success: false };
    },
    showConfirmModal: (state, action: PayloadAction<ConfirmModal>) => {
      return { ...state, confirmModal: action.payload };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(updateUserProfile.pending, (state) => {
        state.loading = true;
        state.error = { ...state.error, errorString: "" };
        state.success = false;
      })
      .addCase(updateUserProfile.fulfilled, (state, action) => {
        // console.log(action.payload);
        state.user = action.payload.data;
        state.message = action.payload.message;
        state.success = true;
        state.loading = false;
      })
      .addCase(updateUserProfile.rejected, (state, action: any) => {
        console.log(action.payload);
        state.error = { ...state.error, errorString: action.payload.message };
        state.success = false;
        state.loading = false;
      });
    builder
      .addCase(deleteUserAccount.pending, (state) => {
        state.loading = true;
        state.error = { ...state.error, errorString: "" };
        state.success = false;
      })
      .addCase(deleteUserAccount.fulfilled, (state, action) => {
        // console.log(action.payload);

        state.message = action.payload;
        state.success = true;
        state.loading = false;
      })
      .addCase(deleteUserAccount.rejected, (state, action: any) => {
        console.log(action.payload);
        state.error = { ...state.error, errorString: action.payload.message };
        state.success = false;
        state.loading = false;
      });
  },
});

export const { resetMessage, showConfirmModal } = profileSlice.actions;

export default profileSlice.reducer;
