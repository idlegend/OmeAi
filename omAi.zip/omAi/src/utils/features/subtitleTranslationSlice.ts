import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { SubtitleTranslateInitialState } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: SubtitleTranslateInitialState = {
  success: false,
  loading: false,
  error: false,
  data: {
    file_path: "",
    raw_srt: "",
  },
  messages: [],
  name: "",
};

export const sendSubtitleTranslateQuery = createAsyncThunk(
  "sendSubtitleTranslateQuery",
  async (
    query: {
      file?: File;
      from?: string;
      to?: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const formData = new FormData();
      for (const key in query) {
        formData.append(key, query[key]);
      }
      const res = await axios.post("/user/translation/srt-translate", formData);
      return { data: res.data, to: query.to };
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const subtitleTranslationSlice = createSlice({
  name: "subtitleTranslate",
  initialState,
  reducers: {
    // updateMessages: (state, action) => {
    //   console.log(action.payload);
    //   sessionStorage.setItem(
    //     "messages",
    //     JSON.stringify([...state.messages, action.payload])
    //   );
    //   return { ...state, messages: [...state.messages, action.payload] };
    // },
    updateFileName: (state, action) => {
      state.name = action.payload;
    },
    resetError: (state) => {
      state.error = false;
    },
    clearData: (state) => {
      state.data = {
        file_path: "",
        raw_srt: "",
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendSubtitleTranslateQuery.pending, (state) => {
        state.loading = true;
        state.error = false;
        state.success = false;
      })
      .addCase(sendSubtitleTranslateQuery.fulfilled, (state, action) => {
        state.data = action.payload.data;
        state.name = `${state.name}-${action.payload.to}.srt`;
        state.error = false;
        state.success = false;
        state.loading = false;
      })
      .addCase(sendSubtitleTranslateQuery.rejected, (state, action) => {
        console.log(action.payload);
        state.error = true;
        state.success = false;
        state.loading = false;
      });
  },
});

export const { clearData, updateFileName, resetError } =
  subtitleTranslationSlice.actions;

export default subtitleTranslationSlice.reducer;
