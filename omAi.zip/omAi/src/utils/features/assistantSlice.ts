import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { AssistantInitialState } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: AssistantInitialState = {
  success: false,
  loading: false,
  error: false,
  data: {
    text: "",
    date: "",
    time: "",
    chatTime: "",
    dateTime: "",
  },
  messages: [],
};

export const sendAssistantQuery = createAsyncThunk(
  "sendAssistantQuery",
  async (query: string, { rejectWithValue }) => {
    try {
      const res = await axios.post("/user/translation/knowledge-assistance", {
        question: query,
      });
      return res.data.data;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const assistantSlice = createSlice({
  name: "assistant",
  initialState,
  reducers: {
    updateMessages: (state, action) => {
      sessionStorage.setItem(
        "messages",
        JSON.stringify([...state.messages, action.payload])
      );
      return { ...state, messages: [...state.messages, action.payload] };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendAssistantQuery.pending, (state) => {
        state.loading = true;
        state.error = false;
        state.success = false;
      })
      .addCase(sendAssistantQuery.fulfilled, (state, action) => {
        state.messages = [...state.messages, action.payload];
        state.data = action.payload;
        state.error = false;
        state.success = false;
        state.loading = false;
      })
      .addCase(sendAssistantQuery.rejected, (state, action: any) => {
        console.log(action.payload);
        state.messages = [
          ...state.messages,
          {
            text: "An error occurred, try again later.",
            time: new Date().toLocaleTimeString(),
          },
        ];
        state.error = true;
        state.success = false;
        state.loading = false;
      });
  },
});

export const { updateMessages } = assistantSlice.actions;

export default assistantSlice.reducer;
