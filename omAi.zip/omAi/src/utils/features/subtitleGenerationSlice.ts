import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { SubtitleGenerationInitialState } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: SubtitleGenerationInitialState = {
  success: false,
  loading: false,
  error: false,
  data: {
    filename: "",
    srt_path: "",
    content: "",
  },
  name: "",
  messages: [],
};

export const sendSubtitleGenerateQuery = createAsyncThunk(
  "sendSubtitleGenerateQuery",
  async (
    query: {
      file?: File;
      from?: string;
      to?: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const formData = new FormData();
      for (const key in query) {
        formData.append(key, query[key]);
      }
      const res = await axios.post("/user/translation/transcription", formData);
      return res.data.data;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const subtitleGenerationSlice = createSlice({
  name: "subtitleGeneration",
  initialState,
  reducers: {
    // updateMessages: (state, action) => {
    //   console.log(action.payload);
    //   sessionStorage.setItem(
    //     "messages",
    //     JSON.stringify([...state.messages, action.payload])
    //   );
    //   return { ...state, messages: [...state.messages, action.payload] };
    // },
    updateFileName: (state, action) => {
      state.name = action.payload;
    },
    resetError: (state) => {
      state.error = false;
    },
    clearData: (state) => {
      state.data = {
        filename: "",
        srt_path: "",
        content: "",
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendSubtitleGenerateQuery.pending, (state) => {
        state.loading = true;
        state.error = false;
        state.success = false;
      })
      .addCase(sendSubtitleGenerateQuery.fulfilled, (state, action) => {
        state.data = action.payload;
        state.error = false;
        state.success = false;
        state.loading = false;
      })
      .addCase(sendSubtitleGenerateQuery.rejected, (state, action) => {
        console.log(action.payload);
        state.error = true;
        state.success = false;
        state.loading = false;
      });
  },
});

export const { clearData, updateFileName, resetError } =
  subtitleGenerationSlice.actions;

export default subtitleGenerationSlice.reducer;
