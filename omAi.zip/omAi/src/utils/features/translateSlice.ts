import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { TranslateInitialState } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: TranslateInitialState = {
  success: false,
  loading: false,
  error: false,
  data: {
    text: "",
    translated: "",
  },
  messages:[]
};

export const sendTranslateQuery = createAsyncThunk(
  "sendTranslateQuery",
  async (
    query: {
      text?: string;
      from?: string;
      to?: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const res = await axios.post("/user/translation/translate", query);
      return res.data.data;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const translateSlice = createSlice({
  name: "translate",
  initialState,
  reducers: {
    // updateMessages: (state, action) => {
    //   console.log(action.payload);
    //   sessionStorage.setItem(
    //     "messages",
    //     JSON.stringify([...state.messages, action.payload])
    //   );
    //   return { ...state, messages: [...state.messages, action.payload] };
    // },
    clearData: (state) => {
      state.data = {
        text: "",
        translated: "",
      };
    },
    resetError: (state) => {
      state.error = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendTranslateQuery.pending, (state) => {
        state.loading = true;
        state.error = false;
        state.success = false;
      })
      .addCase(sendTranslateQuery.fulfilled, (state, action) => {
        // console.log(action.payload);
        state.data = action.payload;
        state.error = false;
        state.success = false;
        state.loading = false;
      })
      .addCase(sendTranslateQuery.rejected, (state, action) => {
        console.log(action.payload);
        state.error = true;
        state.success = false;
        state.loading = false;
      });
  },
});

export const { clearData, resetError } = translateSlice.actions;

export default translateSlice.reducer;
