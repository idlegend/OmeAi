import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { LiteracyInitialState } from "../../interfaces";
import axios, { AxiosError } from "axios";

const initialState: LiteracyInitialState = {
  success: false,
  loading: false,
  error: false,
  data: {
    text: "",
    date: "",
    time: "",
    chatTime: "",
    dateTime: "",
  },
  literacyMessages: [],
};

export const sendLiteracyQuery = createAsyncThunk(
  "sendLiteracyQuery",
  async (query: string, { rejectWithValue }) => {
    try {
      const res = await axios.post("/user/translation/digital-literacy", {
        question: query,
      });
      return res.data.data;
    } catch (error) {
      const axError = error as AxiosError;
      if (axError.response && axError.response.data) {
        return rejectWithValue(axError.response.data);
      } else {
        return rejectWithValue(axError.message);
      }
    }
  }
);

export const literacySlice = createSlice({
  name: "literacy",
  initialState,
  reducers: {
    updateMessages: (state, action) => {
      //   sessionStorage.setItem(
      //     "messages",
      //     JSON.stringify([...state.messages, action.payload])
      //   );
      return {
        ...state,
        literacyMessages: [...state.literacyMessages, action.payload],
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendLiteracyQuery.pending, (state) => {
        state.loading = true;
        state.error = false;
        state.success = false;
      })
      .addCase(sendLiteracyQuery.fulfilled, (state, action) => {
        state.literacyMessages = [...state.literacyMessages, action.payload];
        state.data = action.payload;
        state.error = false;
        state.success = false;
        state.loading = false;
      })
      .addCase(sendLiteracyQuery.rejected, (state, action: any) => {
        console.log(action.payload);
        state.literacyMessages = [
          ...state.literacyMessages,
          {
            text: "An error occurred, try again later.",
            time: new Date().toLocaleTimeString(),
          },
        ];
        state.error = true;
        state.success = false;
        state.loading = false;
      });
  },
});

export const { updateMessages } = literacySlice.actions;

export default literacySlice.reducer;
