export interface LogInData {
  user?: User;
  token?: string;
}

export interface InitialUserState {
  user: User;
  sidebar: string;
  loading: boolean | null | string;
  success: boolean | null | string;
  error: {
    default: string;
    errorString: string;
  };
  message: string;
  otpSent: boolean;
}
export interface InitialProfileState {
  user: User;
  loading: boolean;
  deleteLoading:boolean;
  success: boolean;
  error: {
    default: string;
    errorString: string;
  };
  message: string;
  confirmModal:ConfirmModal
}
export interface ConfirmModal {
  content:string;
  show: boolean
}

export interface ProfileFormState {
  first_name: string;
  last_name: string;
  phone_number: string;
  email: string;
  image?: string | File;
}
export interface User {
  id?: number;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
  email?: string;
  imageUrl?: string;
  roles: Role[];
}
export interface Role {
  id: number;
  name: string;
  guard_name: string;
  created_at: string;
  updated_at: string;
}

export interface Subpage {
  name: string;
  path: string;
  element: React.FC;
}

export interface Route {
  icon: ({ fill }: { fill: string }) => JSX.Element;
  name: string;
  path: string;
  element: React.FC;
  subpages: Subpage[];
}

export interface OrgsResponse {
  status: string;
  message: string;
  data: Organisation[];
}

export interface Organisation {
  id: number;
  uuid: string;
  organization_name: string;
  phone_number: string;
  address: string;
  about_organization: string;
  imageUrl: string;
  available_type: number;
  is_offline: number;
  offline_message: string;
  cv_filename: string;
  cv_file: number;
  status: number;
  created_at: string;
  updated_at: string;
  user: OrganisationUser;
}

export interface OrganisationUser {
  id: number;
  first_name: string;
  last_name: string;
  phone_number: string;
  email: string;
  imageUrl: string;
  created_at: string;
  updated_at: string;
}

export interface AppInitialState {
  orgs: Organisation[];
  filteredOrgs: Organisation[];
  filterVal: null | number;
  loading: boolean;
  error?: string;
  success: boolean;
  isModalOpen: boolean;
  courseCategories: Category[];
  courses: Course[];
  modalContent: string;
  courseToEdit: null | Course;
  lessons: LessonData[];
  lessonToEdit: LessonData[] | null;
  videoUrl: string;
}

export interface LessonData {
  course_id: number;
  name: string;
  short_description: string;
  uuid: string;
  updated_at: string;
  created_at: string;
  id: number;
}

export interface CreateOrgForm {
  email: string;
  organization_name: string;
  phone_number: string;
  address: string;
  password: string;
  about_organization: string;
  imageUrl: File | null;
}
export interface CreateCourseForm {
  title: string;
  category_id: number;
  price: number;
  learner_accessibility: string;
  description: string;
  subtitle: string;
  image?: File | null | string;
  drip_content: number;
  status: number;
}

export interface CreateOrgPostData {
  first_name: string;
  last_name: string;
  email: string;
  organization_name: string;
  phone_number: string;
  address: string;
  password: string;
  about_organization: string;
}

export interface LoginFormData {
  email: string;
  password: string;
}

export interface CreateLessonTitleState {
  title: string;
  course_uuid?: string;
}

export interface Category {
  name: string;
  is_feature: string;
  slug: string;
  imageUrl: string;
  uuid: string;
  id?: number;
}

export interface CategoriesInitialState {
  success: string | null;
  loading: boolean;
  categories: Category[];
  category: Category;
  error?: string | null;
  categoryToEdit: CreateCategoryForm | Category;
}

export interface CreateCategoryForm {
  name?: string;
  image?: null | File;
}

export interface Question {
  name: string;
  is_correct_answer: string;
  type: string;
  options: QuestionOptions;
}

export interface QuestionOptions {
  option1: string;
  option2: string;
  option3: string;
  option4: string;
}

export interface Course {
  id: number;
  uuid: string;
  title: string;
  subtitle: string;
  category: string;
  slug: string;
  price: string;
  old_price: string;
  course_type: number;
  learner_accessibility: string;
  image: string;
  video: string;
  youtube_video_id: string;
  average_rating: string;
  drip_content: number;
  access_period: number;
  intro_video_check: number;
  private_mode: number;
  status: number;
  total_course_lesson: number;
  total_course_lecture: number;
  total_course_resource: number;
  total_course_duration: string;
  total_course_enrollments: number;
  addedToWishList: boolean;
  isEnroll: boolean;
  course_enroll: CourseEnroll;
  user: CourseUser;
  created_at: string;
  updated_at: string;
}

export interface CourseEnroll {
  id: number;
  completed_time: string;
  start_date: string;
  end_date: string;
  status: string;
  course: string;
  course_owner: string;
  enrolled_user: string;
  created_at: string;
  updated_at: string;
}

export interface CourseUser {
  id: number;
  first_name: string;
  last_name: string;
  phone_number: string;
  email: string;
  imageUrl: string;
  roles: CourseUserRole[];
  created_at: string;
  updated_at: string;
}

export interface CourseUserRole {
  id: number;
  name: string;
  guard_name: string;
  created_at: string;
  updated_at: string;
  pivot: CourseUserRolePivot;
}

export interface CourseUserRolePivot {
  model_id: number;
  role_id: number;
  model_type: string;
}

export interface DeleteCourseResponse {
  status: string;
  message: string;
  data: null;
}

export interface VideoUploadResponse {
  id: number;
  uuid: string;
  title: string;
  file_path: string;
  audio_path: string;
  srt_path: string;
  file_size: string;
  file_duration: string;
  file_duration_second: number;
  type: string;
  srt_files: string[];
  audio_files: string[];
  status: number;
  watched: boolean;
  lecture: string[];
  created_at: string;
  updated_at: string;
}

export interface VideoUploadForm {
  title?: string;
  video_file: File | null;
  course_uuid?: string;
  lesson_uuid?: string;
}

export interface LessonCourseIds {
  course_id: number;
  lesson_id: number;
}

export interface LessonVideo {
  id: number;
  uuid: string;
  title: string;
  file_path: string;
  audio_path: string;
  srt_path: string;
  file_size: string;
  file_duration: string;
  file_duration_second: number;
  type: string;
  srt_files: LessonSrtFile[];
  audio_files: LessonAudioFile[];
  status: string;
  watched: boolean;
  lecture: string[];
  created_at: string;
  updated_at: string;
  lesson: LessonDataInVideo;
}

export interface LessonDataInVideo {
  id: number;
  uuid: string;
  course_id: number;
  name: string;
  short_description: string;
  created_at: string;
  updated_at: string;
}

export interface LessonSrtFile {
  id: number;
  uuid: string;
  name: string;
  path: string;
  file_size: string;
  created_at: string;
  updated_at: string;
}

export interface LessonAudioFile {
  id: number;
  uuid: string;
  name: string;
  path: string;
  file_size: string;
  created_at: string;
  updated_at: string;
}

export interface AssistantInitialState {
  success: boolean;
  loading: boolean;
  data: AssistantResponseData;
  error: boolean;
  messages: any;
}
export interface LiteracyInitialState {
  success: boolean;
  loading: boolean;
  data: AssistantResponseData;
  error: boolean;
  literacyMessages: any;
}

export interface AssistantResponse {
  status: string;
  message: string;
  data: AssistantResponseData;
}

export interface AssistantResponseData {
  text: string;
  date: string;
  time: string;
  chatTime: string;
  dateTime: string;
}
export interface TranslateInitialState {
  success: boolean;
  loading: boolean;
  data: TranslateResponseData;
  error: boolean;
  messages: object[];
}

export interface SubtitleTranslateInitialState {
  success: boolean;
  loading: boolean;
  data: SubtitleTranslationResponseData;
  error: boolean;
  name: string;
  messages: object[];
}
export interface SubtitleGenerationInitialState {
  success: boolean;
  loading: boolean;
  name: string;
  data: SubtitleGenerationResponseData;
  error: boolean;
  messages: object[];
}

export interface SubtitleTranslationResponseData {
  file_path: string;
  raw_srt: string;
}
export interface SubtitleGenerationResponseData {
  filename: string;
  srt_path: string;
  content: string;
}

export interface TranslateResponse {
  status: string;
  message: string;
  data: TranslateResponseData;
}

export interface TranslateResponseData {
  text: string;
  translated: string;
}
