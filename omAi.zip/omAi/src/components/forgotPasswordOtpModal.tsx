import { Button } from "@material-tailwind/react";
import React, { useEffect, useState } from "react";
import OTPInput, { ResendOTP } from "otp-input-react";
import { useAppDispatch, useAppSelector } from "../utils/store";
import { useNavigate } from "react-router";
import {
  clearSuccess,
  resendOtp,
  verifyCode,
} from "../utils/features/userSlice";
import { CgSpinner } from "react-icons/cg";
import { GrClose } from "react-icons/gr";

const ForgotPasswordOtpModal = ({ email }) => {
  const { otpSent, message, success, loading } = useAppSelector(
    (state) => state.user
  );
  const [OTP, setOTP] = useState<number>();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (success) {
      navigate("/Update-password");
      dispatch(clearSuccess());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [success]);

  if (otpSent) {
    return (
      <section className=" absolute z-40 h-[100vh] w-full flex items-center justify-center bg-[#949090b7]">
        <div
          onClick={(e) => e.stopPropagation()}
          className="card-bg py-20 px-10 w-[80%] md:w-[500px] relative flex justify-center items-center  bg-white"
        >
          <GrClose
            onClick={() => dispatch(clearSuccess())}
            className="absolute top-5 right-5  w-5 h-5 text-red-500"
          />
          <div className=" w-[100%] md:w-2/3 space-y-10 flex flex-col justify-center items-center">
            <p className="text-center">Kindly check your email for an OTP</p>
            {message && message !== "Check your email for an OTP" ? (
              <div className="w-full bg-green-500 relative py-2 px-2 rounded">
                <p className="text-white">{message}</p>
              </div>
            ) : null}
            <div className="text-center space-y-2">
              <OTPInput
                className="last"
                inputClassName="outline-[#201AFF] border rounded-sm text-[#201AFF] !mr-[13px] md:!mr-[20px]"
                value={OTP}
                onChange={setOTP}
                autoFocus
                OTPLength={4}
                otpType="number"
                disabled={false}
                secure
              />

              <ResendOTP
                style={{ marginTop: "1rem" }}
                renderButton={renderButton}
                renderTime={renderTime}
                onResendClick={() => dispatch(resendOtp(""))}
              />
            </div>
            <Button
            //   onClick={() => dispatch(verifyCode(OTP.toString()))}
            onClick={() => {
                if (OTP && email) {
                  dispatch(verifyCode({ OTP: OTP.toString(), email }));
                }
              }}              disabled={typeof loading == "boolean" ? loading : null}
              className="text-sm w-3/4  mt-36  self-center flex items-center justify-center px-6 py-3 rounded-md text-white font-normal capitalize  bg-primary"
            >
              {loading ? (
                <CgSpinner className="text-white w-[25px] h-[25px] animate-spin" />
              ) : (
                "Verify"
              )}
            </Button>
          </div>
        </div>
      </section>
    );
  }
};

export default ForgotPasswordOtpModal;

const renderButton = (buttonProps) => {
  return (
    <button {...buttonProps}>
      {buttonProps.remainingTime !== 0
        ? `Please wait for ${buttonProps.remainingTime} sec`
        : "Resend"}
    </button>
  );
};

const renderTime = () => React.Fragment;
