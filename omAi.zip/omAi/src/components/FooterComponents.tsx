import { Mail, Phone } from "../assets/icons/contact";
import { Link } from 'react-router-dom';

type Props = {
  title: string;
  links: { title: string; url: string }[];
};

export const FooterLinks: React.FC<Props> = ({ title, links }) => {
  return (
    <div className="theme_text flex flex-col gap-y-[18px]">
      <h1 className="text-sm lg:text-lg font-bold ">{title}</h1>
      <div className="text-xs lg:text-sm flex flex-col gap-y-[14px] ">
        {links.map((link, index) => (
           <Link key={index} to={link.url} className="hover:underline">
          <h1 key={index}>{link.title}</h1>
          </Link>
        ))}
      </div>
    </div>
  );
};

export const FooterContact = () => {
  return (
    <div className="theme_text flex flex-col gap-y-[18px]">
      <h1 className="text-sm lg:text-lg  font-bold ">Contact Us</h1>
      <div className="text-sm flex flex-col gap-y-6 ">
        <div className="flex gap-x-[14px]">
          <Phone />
          <div className="theme_text text-xs lg:text-sm">
            <h1>+2349137160848</h1>
            <h1>+2349131573923</h1>
            <h1>+447441426012</h1>
          </div>
        </div>
        <div className="flex gap-x-[14px]">
          <Mail />
          <div className="theme_text text-xs lg:text-sm">
            <h1>info@uniccongroup.com</h1>
            <h1>lossless@uniccongroup.com</h1>
            <h1>sales@uniccongroup.com</h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export const FooterAddresss = () => {
  return (
    <div className="theme_text flex flex-col gap-y-[18px]">
      <h1 className="text-sm lg:text-lg font-bold ">Location</h1>
      <div className="text-xs lg:text-sm flex flex-col gap-y-6 ">
        <h1>3rd Floor, Lanre Shittu House, Mabushi, Abuja. 900108</h1>
        <h1>28 Kingshold Road, London, England, E97JF.</h1>
      </div>
    </div>
  );
};
