import React from "react";
import Logo from "../../assets/icons/logo";
import Button from "../common/Button";
import TextLink from "../common/TextLink";
import { useNavigate } from "react-router";
import { Icon } from "@iconify/react";

const Header: React.FC<{
  setShowMenu: React.Dispatch<React.SetStateAction<boolean>>;
}> = ({ setShowMenu }) => {
  const navigate = useNavigate();
  return (
    <div className="py-3  sticky top-0 left-0 right-0 !z-50 theme w-full">
      <div className="contain flex relative justify-between items-center ">
        <div className="lg:flex hidden w-full absolute space-x-8 top-0 right-0 bottom-0 left-0 justify-center items-center">
          <TextLink text="Home" route="home" />
          <TextLink text="Features" route="features" />
          <TextLink text="Pricing" route="pricing" />
          <TextLink text="About Us" route="about-us" />
          <TextLink text="Contact Us" route="contact-us" />

          {/* <TextLink text="Home" route="" />
          <TextLink text="Features" route="" />
          <TextLink text="Pricing" route="" />
          <TextLink text="About Us" route="" />
          <TextLink text="Contact Us" route="" /> */}
        </div>
        <div onClick={() => navigate("/home")} className="cursor-pointer !z-50">
          <Logo />
        </div>

        <div className="!z-50 hidden lg:block">
          <Button text="Login" action={() => navigate("/signin")} />
        </div>
        <div className="!z-50 lg:hidden">
          <Icon
            icon="ci:hamburger-md"
            onClick={() => setShowMenu(true)}
            className="text-2xl theme_text"
          />
        </div>
      </div>
    </div>
  );
};

export default Header;
