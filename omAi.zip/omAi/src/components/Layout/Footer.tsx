import { Link } from "react-router-dom";
import Logo from "../../assets/icons/logo";
import {
  Facebook,
  Instagram,
  LinkedIn,
  Twitter,
} from "../../assets/icons/social";
import {
  FooterAddresss,
  FooterContact,
  FooterLinks,
} from "../FooterComponents";

const Footer = () => {
  return (
    <div className="w-full">
      <div className="contain flex flex-col gap-y-9 py-10">
        <div className="grid grid-cols-5 gap-6 ">
          <div className="flex col-span-full lg:col-span-1 flex-col space-y-1">
            <Logo />
            <h1 className="text-xs lg:text-sm theme_text ">
              The Omeife AI App is a revolutionary new AI-powered large language
              model that can generate text in a variety of styles and formats.
            </h1>
          </div>
          <div className="col-span-2 lg:col-span-1">
            <FooterLinks
              title="Company"
              links={[
                { title: "Privacy Policy", url: "/" },
                { title: "Terms & Conditions", url: "/" },
              ]}
            />
          </div>
          <div className="col-span-3 lg:col-span-1">
            <FooterContact />
          </div>
          <div className="col-span-2 lg:col-span-1">
            <FooterLinks
              title="Website Links"
              links={[
                { title: "Home", url: "/home" },
                { title: "Features", url: "/features" },
                { title: "Pricing", url: "/pricing" },
                { title: "About Us", url: "/about-us" },
                { title: "Contact Us", url: "/contact-us" },
              ]}
            />
          </div>
          <div className="col-span-3 lg:col-span-1">
            <FooterAddresss />
          </div>
        </div>
        <div className="flex justify-center lg:justify-start gap-x-5 ">
          <Link to="https://x.com/OmeifeAI?s=20" target="_blank">
            <Twitter />
          </Link>
          <Link to="https://linkedin.com/company/omeife-ai/" target="_blank">
            <LinkedIn />
          </Link>
          <Link to="https://www.facebook.com/omeifeai" target="_blank">
            <Facebook />
          </Link>
          <Link to="https://www.instagram.com/omeifeai/" target="_blank">
            <Instagram />
          </Link>
        </div>
        <div className="border-t border-gray2 pt-2 w-full flex justify-center items-center">
          <h1 className="text-xs lg:text-sm theme_text">
            © 2023 Omeifeai. All rights reserved.{" "}
          </h1>
        </div>
      </div>
    </div>
  );
};

export default Footer;
