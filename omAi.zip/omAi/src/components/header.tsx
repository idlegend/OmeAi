import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../utils/store";
import { routes } from "../routes";
import { NotificationIcon, menuIcon, whitemenu } from "../assets/icons";
import { toggleSidebar } from "../utils/features/userSlice";

export const Header = ({ theme }) => {
  const { user, sidebar } = useAppSelector((state) => state.user);
  const dispatch = useAppDispatch();
  const location = useLocation();
  const path = location.pathname;
  const route = routes.filter((route) => path.includes(route.path));
  const navigate = useNavigate();

  return (
    <>
      <div className=" col-span-3 2xl:col-span-4 flex items-center justify-between py-4 px-3 md:px-6 bg-white dark:bg-[#282828] dark:text-white  rounded-md shadow-[0px_4px_8px_0px_rgba(0,0,0,0.10)]">
        <Link to={route[0]?.path}>
          {" "}
          <h1 className="font-semibold text-base">{route[0]?.name}</h1>
        </Link>
        {user.roles[0].name == "Super Admin" &&
        location.pathname !== "/dashboard" ? (
          <label className="w-2/3 hidden  lg:flex  border rounded-lg  items-center">
            <div className="p-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="30"
                height="30"
                viewBox="0 0 25 25"
                fill="none"
              >
                <path
                  d="M11.6126 15.8947C14.008 15.8947 15.9499 13.9528 15.9499 11.5574C15.9499 9.16206 14.008 7.22021 11.6126 7.22021C9.21724 7.22021 7.27539 9.16206 7.27539 11.5574C7.27539 13.9528 9.21724 15.8947 11.6126 15.8947Z"
                  stroke="black"
                  strokeOpacity="0.34"
                  strokeWidth="0.871054"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M17.9581 17.7108L15.9824 15.7139"
                  stroke="black"
                  strokeOpacity="0.34"
                  strokeWidth="0.871054"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <input
              type="text"
              placeholder="Search"
              className="w-full p-2  text-sm  outline-none "
            />
            <button className="bg-primary m-1 p-1 h-fit  rounded-lg ">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="25"
                viewBox="0 0 20 21"
                fill="none"
              >
                <path
                  d="M9.04881 14.4636C11.8372 14.4636 14.0976 12.2032 14.0976 9.41477C14.0976 6.62639 11.8372 4.36597 9.04881 4.36597C6.26043 4.36597 4 6.62639 4 9.41477C4 12.2032 6.26043 14.4636 9.04881 14.4636Z"
                  stroke="white"
                  strokeWidth="1.01396"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M16.4346 16.5775L14.1348 14.2529"
                  stroke="white"
                  strokeWidth="1.01396"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </label>
        ) : null}
        {theme == "dark" ? (
          <img
            onClick={(e) => {
              dispatch(toggleSidebar(sidebar == "open" ? "close" : "open"));
              e.stopPropagation();
            }}
            src={whitemenu}
            className="cursor-pointer w-7 h-7 lg:hidden dark:text-white"
          />
        ) : (
          <img
            onClick={(e) => {
              dispatch(toggleSidebar(sidebar == "open" ? "close" : "open"));
              e.stopPropagation();
            }}
            src={menuIcon}
            className="cursor-pointer w-7 h-7 lg:hidden dark:text-white"
          />
        )}
      </div>
      <div className="flex flex-row-reverse md:flex-row items-center justify-between py-2 px-3 xl:py-4 xl:px-6 bg-white dark:bg-[#282828] dark:text-white  rounded-md shadow-[0px_4px_8px_0px_rgba(0,0,0,0.10)]">
        <div className="relative hidden md:block">
          <div>
            {theme == "dark" ? (
              <NotificationIcon fill="white" />
            ) : (
              <NotificationIcon fill="black" />
            )}
          </div>
          <div className=" h-1 w-1 bg-[#FF3B30] absolute top-0 right-0 rounded-full"></div>
        </div>
        <div
          onClick={() => navigate("/profile")}
          className="flex flex-row-reverse md:flex-row justify-center space-x-2 md:space-x-6 w-full items-center cursor-pointer"
        >
          <p className="md:hidden capitalize">{`${user.first_name.substring(
            0,
            3
          )}..`}</p>
          <p className=" hidden md:block capitalize">{user.first_name}</p>
          <img
            src={user.imageUrl}
            alt="admin"
            className=" w-4 h-4 lg:w-8 lg:h-8 rounded-full"
          />
        </div>
      </div>
    </>
  );
};
