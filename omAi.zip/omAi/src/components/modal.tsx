import { useAppDispatch, useAppSelector } from "../utils/store";
import { Button } from "@material-tailwind/react";
import { resetError as resetSubtitleTranslationError } from "../utils/features/subtitleTranslationSlice";
import { resetError as resetTranslateError } from "../utils/features/translateSlice";
import { resetError as resetSubtitleGenerateError } from "../utils/features/subtitleGenerationSlice";
import {
  deleteUserAccount,
  resetMessage,
  showConfirmModal,
} from "../utils/features/profileSlice";
import { successIcon } from "../assets/icons";
import { useEffect } from "react";
import { setUser } from "../utils/features/userSlice";
import { GrClose } from "react-icons/gr";
import { useNavigate } from "react-router";
import { User } from "../interfaces";

export const Modal = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const userString = sessionStorage.getItem("user");
  const mainUser: User = userString ? JSON.parse(userString) : null;
  const { error: translateError } = useAppSelector((state) => state.translate);
  const { error: substitleTranslateError } = useAppSelector(
    (state) => state.substitleTranslate
  );
  const { error: subtitleGenerateError } = useAppSelector(
    (state) => state.subtitleGeneration
  );

  const {
    user,
    success,
    message: profileMessage,
    confirmModal,
  } = useAppSelector((state) => state.profile);
  const { show, content } = confirmModal;

  useEffect(() => {
    if (success && profileMessage == "Profile updated successfully") {
      dispatch(setUser({ user, token: "" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [success, profileMessage]);

  if (success && profileMessage) {
    return (
      <section
        className=" absolute z-40 h-full w-full flex items-center justify-center bg-[#949090b7]"
        onClick={() => {
          dispatch(resetMessage());
        }}
      >
        <div
          onClick={(e) => e.stopPropagation()}
          className="card-bg py-20 px-10 w-[300px] md:w-[500px] flex justify-center items-center  bg-white"
        >
          <div className=" w-full md:w-2/3 space-y-10 flex flex-col justify-center items-center">
            <img src={successIcon} className="w-16 h-16" />
            <div className="text-center space-y-2">
              <p className="text-xl font-semibold">{profileMessage}</p>
            </div>
            <Button
              onClick={() => {
                if (
                  profileMessage == "Your account and associated data deleted"
                ) {
                  sessionStorage.clear();
                  navigate("/");
                }
                dispatch(resetMessage());
              }}
              className="text-sm w-3/4  mt-36  self-center px-6 py-3 rounded-md text-white font-normal capitalize  bg-primary"
            >
              Done
            </Button>
          </div>
        </div>
      </section>
    );
  }

  if (translateError || substitleTranslateError || subtitleGenerateError) {
    return (
      <section
        className=" absolute z-40 h-full w-full flex items-center justify-center bg-[#949090b7]"
        onClick={() => {
          dispatch(resetSubtitleTranslationError());
          dispatch(resetTranslateError());
          dispatch(resetSubtitleGenerateError());
        }}
      >
        <div
          onClick={(e) => e.stopPropagation()}
          className="card-bg py-20 px-10 w-[500px] flex justify-center items-center  bg-white"
        >
          <div className=" w-2/3 space-y-10 flex flex-col justify-center items-center">
            <div className="text-center space-y-2">
              <p className="text-xl">Something went wrong</p>
            </div>
            <Button
              onClick={() => {
                dispatch(resetSubtitleTranslationError());
                dispatch(resetTranslateError());
                dispatch(resetSubtitleGenerateError());
              }}
              className="text-sm w-3/4  mt-36  self-center px-6 py-3 rounded-md text-white font-normal capitalize  bg-primary"
            >
              Ok
            </Button>
          </div>
        </div>
      </section>
    );
  }

  if (show) {
    return (
      <section
        className=" absolute z-40 h-full w-full flex items-center justify-center bg-[#949090b7]"
        onClick={() => {
          dispatch(showConfirmModal({ show: false, content: "" }));
        }}
      >
        <div
          onClick={(e) => e.stopPropagation()}
          className="card-bg py-20 px-10  w-[80%] md:w-[500px] relative flex justify-center items-center  bg-white"
        >
          <GrClose
            onClick={() => {
              dispatch(showConfirmModal({ show: false, content: "" }));
            }}
            className="absolute top-5 right-5  w-5 h-5 text-red-500 cursor-pointer dark:text-white"
          />
          <div className=" w-full md:w-2/3 space-y-12 flex flex-col justify-center items-center">
            <div className="text-center space-y-2">
              <p className="">
                Are you sure you want to {content}?
              </p>
            </div>
            <div className="flex w-full space-x-10">
              <Button
                onClick={() => {
                  dispatch(showConfirmModal({ show: false, content: "" }));
                }}
                className="text-sm w-3/4    self-center px-6 py-3 rounded-md text-white font-normal capitalize  bg-primary"
              >
                No
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (content == "delete your account") {
                    dispatch(
                      deleteUserAccount({
                        email: mainUser.email,
                        message:
                          "i want to delete my account with all the data on it!",
                      })
                    );
                  } else {
                    sessionStorage.clear();
                    navigate("/");
                    dispatch(showConfirmModal({ show: false, content: "" }));
                  }
                }}
                className="text-sm w-3/4   self-center px-6 py-3 rounded-md  capitalize border-primary text-primary dark:text-white"
              >
                Yes
              </Button>
            </div>
          </div>
        </div>
      </section>
    );
  }
};
