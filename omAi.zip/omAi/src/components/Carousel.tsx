import { CarouselContext, Dot, Slide, Slider } from "pure-react-carousel";
import { useContext, useEffect, useState } from "react";

const array = [
  {
    name: "Mary Jane",
    review:
      "Unlike other AI apps, Omeife AI fully represents the African culture and ethos. Having an AI that can communicate in my local dialect is impressive",
  },
  {
    name: "Glory Dora",
    review:
      "I asked Omeife some questions for my research on the Benin Kingdom and her answer was detailed and really helpful. I loved the user experience, I’ll recommend",
  },
  {
    name: "Philip Dan",
    review:
      "As a content creator I look for tools that can make my work easier and help my content get to a wider audience. I was really impressed when with a few click I was able to generate SRT translation for my content to multiply African languages using the Omeife AI",
  },
  {
    name: "Steve Gold",
    review:
      "The app responsiveness is optimum and the app interface is amazing and easy to use",
  },
];

const Carousel = () => {
  const carouselContext = useContext(CarouselContext);
  const [currentSlide, setCurrentSlide] = useState(
    carouselContext.state.currentSlide
  );

  useEffect(() => {
    function onChange() {
      setCurrentSlide(carouselContext.state.currentSlide);
    }
    carouselContext.subscribe(onChange);
    return () => carouselContext.unsubscribe(onChange);
  }, [carouselContext]);

  return (
    <div className="relative space-y-4 w-full h-full">
      <Slider className="w-full   h-full">
        {array.map((item, index) => (
          <Slide key={index} index={index}>
            <div className="flex flex-col rounded-md shadow_box border-2 dark:border-gray-100/10 items-center gap-y-2 lg:gap-y-12 p-8 lg:p-16">
              <h1 className=" text-[10px] lg:text-base theme_text text-center max-w-[500px]">
                {item.review}
              </h1>
              <div className="w-full flex justify-end">
                <h1 className=" text-xs lg:text-xl theme_text font-bold ">
                  -{item.name}
                </h1>
              </div>
            </div>
          </Slide>
        ))}
      </Slider>
      <div className="space-x-3 w-full flex justify-center items-center">
        {array.map((_, index) => {
          if (currentSlide === index) {
            return (
              <Dot
                key={index}
                className="w-5 h-[10px] bg-primary rounded-full "
                slide={index}
              />
            );
          } else {
            return (
              <Dot
                className={`w-[10px] h-[10px]  border border-primary/60 rounded-full`}
                key={index}
                slide={index}
              ></Dot>
            );
          }
        })}
      </div>
    </div>
  );
};

export default Carousel;
