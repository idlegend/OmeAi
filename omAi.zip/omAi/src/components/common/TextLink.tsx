import React from "react";
import { Link, useLocation } from "react-router-dom";

type Props = {
  text: string;
  route: string;
};

const TextLink: React.FC<Props> = ({ text, route }) => {
  const location = useLocation();
  const currentRoute = location.pathname.split("/")[1];
  const active = currentRoute.toLowerCase() === route.toLowerCase();
  return (
    <Link to={`/${route}`} className="relative">
      <h3 className="text-base cursor-pointer theme_text ">{text}</h3>
      {active && (
        <div className="w-full absolute left-0 -bottom-[6px] right-0 h-[3px] rounded-full bg-primary"></div>
      )}
    </Link>
  );
};

export default TextLink;
