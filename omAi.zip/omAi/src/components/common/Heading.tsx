import React from "react";
import {
  ColoredEllipsesLeft,
  ColoredEllipsesRight,
} from "../../assets/icons/Ellipses";

type Props = {
  text: string;
};

const Heading: React.FC<Props> = ({ text }) => {
  return (
    <div className="w-full flex items-center justify-center gap-x-4 lg:gap-x-11">
      <ColoredEllipsesLeft />
      <h1 className=" text-lg lg:text-4xl font-bold theme_text ">{text}</h1>
      <ColoredEllipsesRight />
    </div>
  );
};

export default Heading;
