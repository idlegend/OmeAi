import React from "react";

type Props = {
  text: string;
  image: string;
  description: string;
};

const FeatureCard: React.FC<Props> = ({ text, image, description }) => {
  return (
    <div className="py-[10px] rounded-full px-4 gradient_box flex items-center gap-x-3 lg:gap-x-6 ">
      <div>
        <div className="w-[45px] h-[45px] lg:w-[128px] rounded-full lg:h-[128px] theme flex justify-center items-center ">
          <img
            src={image}
            className="w-[25px] h-[25px] lg:w-[80px] lg:h-[80px] "
          />
        </div>
      </div>
      <div className="flex flex-col gap-y-[2px] lg:gap-y-2 ">
        <h1 className="text-[11px] lg:text-xl theme_text font-bold ">{text}</h1>
        <h3 className="text-[8px] lg:text-base theme_text">{description}</h3>
      </div>
    </div>
  );
};

export default FeatureCard;
