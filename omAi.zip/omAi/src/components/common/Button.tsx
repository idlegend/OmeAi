import React from "react";

type Props = {
  text: string;
  action?: () => void;
  type?: "button" | "submit" | "reset";
};

const Button: React.FC<Props> = ({ text, action, type = "button" }) => {
  return (
    <button
      type={type}
      onClick={action}
      className="py-4 w-fit px-14 rounded-[10px] text-sm lg:text-base bg-primary text-white"
    >
      {text}
    </button>
  );
};

export default Button;
