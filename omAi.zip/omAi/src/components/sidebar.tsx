import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { LogoutIcon, mainLogo } from "../assets/icons";
import { routes } from "../routes";
import { User } from "../interfaces";
import { useAppDispatch, useAppSelector } from "../utils/store";
import { setUser, toggleSidebar } from "../utils/features/userSlice";
import { showConfirmModal } from "../utils/features/profileSlice";

export const Sidebar = ({ theme, setTheme }) => {
  const dispatch = useAppDispatch();
  const location = useLocation();
  const url = location.pathname;
  const userString = sessionStorage.getItem("user");
  const user: User = userString ? JSON.parse(userString) : null;
  const { user: userSlice, sidebar } = useAppSelector((state) => state.user);
  const [fill, setFill] = React.useState("#A4A2FE");
  const [width, setWidth] = React.useState(window.innerWidth);

  useEffect(() => {
    dispatch(setUser({ user, token: "null" }));
  }, []);
  const handleResize = () => {
    setWidth(window.innerWidth);
  };
  useEffect(() => {
    window.addEventListener("resize", handleResize, false);
  }, []);
  useEffect(() => {
    if (width < 786) {
      dispatch(toggleSidebar("open"));
    } else {
      dispatch(toggleSidebar("close"));
    }
  }, [width, dispatch]);

  const handleLogout = () => {
    dispatch(toggleSidebar("close"));
    dispatch(showConfirmModal({ show: true, content: "logout" }));
  };

  return (
    <div
      className={`bg-primary overflow-auto flex-1 max-w-[323px] ${
        width < 786
          ? `absolute z-50 h-[100vh] transition-all duration-300 delay-150 ${
              sidebar == "close" ? "-left-[500px]" : "left-0"
            }`
          : "relative"
      }`}
    >
      <div className="flex items-center justify-between px-3 pt-3 xl:px-6 xl:pt-6 relative ">
        <img src={mainLogo} alt="Omeife" className="w-[52px]" />
        <button
          onClick={() =>
            setTheme((prev) => {
              if (prev == "dark") {
                return (prev = "light");
              } else {
                return (prev = "dark");
              }
            })
          }
          className="abs"
        >
          {theme == "dark" ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
            >
              <path
                d="M12 17C14.7614 17 17 14.7614 17 12C17 9.23858 14.7614 7 12 7C9.23858 7 7 9.23858 7 12C7 14.7614 9.23858 17 12 17Z"
                fill="white"
              />
              <path
                d="M21 13H20C19.7348 13 19.4804 12.8946 19.2929 12.7071C19.1054 12.5196 19 12.2652 19 12C19 11.7348 19.1054 11.4804 19.2929 11.2929C19.4804 11.1054 19.7348 11 20 11H21C21.2652 11 21.5196 11.1054 21.7071 11.2929C21.8946 11.4804 22 11.7348 22 12C22 12.2652 21.8946 12.5196 21.7071 12.7071C21.5196 12.8946 21.2652 13 21 13Z"
                fill="white"
              />
              <path
                d="M4 13H3C2.73478 13 2.48043 12.8946 2.29289 12.7071C2.10536 12.5196 2 12.2652 2 12C2 11.7348 2.10536 11.4804 2.29289 11.2929C2.48043 11.1054 2.73478 11 3 11H4C4.26522 11 4.51957 11.1054 4.70711 11.2929C4.89464 11.4804 5 11.7348 5 12C5 12.2652 4.89464 12.5196 4.70711 12.7071C4.51957 12.8946 4.26522 13 4 13Z"
                fill="white"
              />
              <path
                d="M17.6598 7.34011C17.4114 7.32886 17.1761 7.22547 16.9998 7.05011C16.8135 6.86275 16.709 6.6093 16.709 6.34511C16.709 6.08092 16.8135 5.82747 16.9998 5.64011L17.7098 4.93011C17.7994 4.82543 17.9097 4.74041 18.0338 4.68038C18.1579 4.62036 18.293 4.58663 18.4307 4.58131C18.5684 4.57599 18.7058 4.5992 18.8341 4.64947C18.9624 4.69975 19.079 4.776 19.1764 4.87346C19.2739 4.97091 19.3501 5.08746 19.4004 5.21579C19.4507 5.34411 19.4739 5.48144 19.4686 5.61916C19.4633 5.75688 19.4295 5.89202 19.3695 6.01608C19.3095 6.14015 19.2245 6.25046 19.1198 6.34011L18.4098 7.05011C18.3116 7.14772 18.1943 7.2239 18.0652 7.27382C17.9361 7.32374 17.7981 7.34631 17.6598 7.34011Z"
                fill="white"
              />
              <path
                d="M5.63946 19.3602C5.50786 19.361 5.3774 19.3358 5.25556 19.286C5.13372 19.2362 5.0229 19.1629 4.92946 19.0702C4.74321 18.8829 4.63867 18.6294 4.63867 18.3652C4.63867 18.101 4.74321 17.8476 4.92946 17.6602L5.63946 17.0002C5.83077 16.8364 6.07684 16.7508 6.32852 16.7605C6.58019 16.7702 6.81893 16.8746 6.99703 17.0527C7.17512 17.2308 7.27945 17.4695 7.28918 17.7212C7.2989 17.9728 7.21329 18.2189 7.04946 18.4102L6.33946 19.1202C6.1454 19.2868 5.8949 19.3727 5.63946 19.3602Z"
                fill="white"
              />
              <path
                d="M12 5C11.7348 5 11.4804 4.89464 11.2929 4.70711C11.1054 4.51957 11 4.26522 11 4V3C11 2.73478 11.1054 2.48043 11.2929 2.29289C11.4804 2.10536 11.7348 2 12 2C12.2652 2 12.5196 2.10536 12.7071 2.29289C12.8946 2.48043 13 2.73478 13 3V4C13 4.26522 12.8946 4.51957 12.7071 4.70711C12.5196 4.89464 12.2652 5 12 5Z"
                fill="white"
              />
              <path
                d="M12 22C11.7348 22 11.4804 21.8946 11.2929 21.7071C11.1054 21.5196 11 21.2652 11 21V20C11 19.7348 11.1054 19.4804 11.2929 19.2929C11.4804 19.1054 11.7348 19 12 19C12.2652 19 12.5196 19.1054 12.7071 19.2929C12.8946 19.4804 13 19.7348 13 20V21C13 21.2652 12.8946 21.5196 12.7071 21.7071C12.5196 21.8946 12.2652 22 12 22Z"
                fill="white"
              />
              <path
                d="M6.33991 7.33991C6.07757 7.33881 5.82617 7.23465 5.63991 7.04991L4.92991 6.33991C4.76608 6.14861 4.68048 5.90253 4.6902 5.65086C4.69992 5.39918 4.80425 5.16044 4.98235 4.98235C5.16044 4.80425 5.39918 4.69992 5.65086 4.6902C5.90253 4.68048 6.14861 4.76608 6.33991 4.92991L7.04991 5.63991C7.23616 5.82727 7.3407 6.08072 7.3407 6.34491C7.3407 6.6091 7.23616 6.86255 7.04991 7.04991C6.95647 7.14259 6.84565 7.21592 6.72382 7.26568C6.60198 7.31545 6.47152 7.34067 6.33991 7.33991Z"
                fill="white"
              />
              <path
                d="M18.3591 19.3601C18.0968 19.359 17.8454 19.2549 17.6591 19.0701L16.9991 18.3601C16.8935 18.1701 16.8526 17.9509 16.8827 17.7356C16.9128 17.5203 17.0122 17.3206 17.1659 17.1669C17.3197 17.0132 17.5193 16.9138 17.7346 16.8837C17.9499 16.8536 18.1692 16.8944 18.3591 17.0001L19.0691 17.7101C19.2554 17.8975 19.3599 18.1509 19.3599 18.4151C19.3599 18.6793 19.2554 18.9328 19.0691 19.1201C18.8725 19.2891 18.618 19.3752 18.3591 19.3601Z"
                fill="white"
              />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
            >
              <path
                d="M20.2107 15.3201C19.6269 16.7063 18.6881 17.9143 17.489 18.8222C16.2898 19.7302 14.8725 20.3062 13.3799 20.4921C11.8873 20.6781 10.3721 20.4674 8.98679 19.8814C7.60149 19.2954 6.39507 18.3547 5.48901 17.1541C4.58296 15.9535 4.00926 14.5353 3.8257 13.0424C3.64214 11.5495 3.8552 10.0346 4.44342 8.65025C5.03165 7.2659 5.97426 6.06098 7.17633 5.15684C8.37841 4.25271 9.7975 3.68128 11.2907 3.50011C11.3943 3.48774 11.4992 3.50808 11.5906 3.55829C11.6821 3.6085 11.7555 3.68606 11.8007 3.78011C11.8479 3.87242 11.8647 3.97734 11.8485 4.07976C11.8323 4.18219 11.7841 4.27685 11.7107 4.35011C11.0977 4.95821 10.6129 5.68302 10.2848 6.4817C9.95676 7.28038 9.79214 8.13672 9.80069 9.00011C9.80949 10.135 10.1121 11.2482 10.6791 12.2313C11.246 13.2144 12.058 14.0339 13.0358 14.61C14.0136 15.186 15.124 15.4989 16.2587 15.5182C17.3935 15.5375 18.5138 15.2625 19.5107 14.7201C19.6033 14.6723 19.708 14.6535 19.8114 14.666C19.9149 14.6784 20.0121 14.7217 20.0907 14.7901C20.1576 14.8588 20.2043 14.9447 20.2254 15.0382C20.2466 15.1317 20.2415 15.2293 20.2107 15.3201Z"
                fill="white"
              />
            </svg>
          )}
        </button>
      </div>
      <div>
        <ul className="px-3 py-4 xl:px-6 lg:py-8  list-none text-white text-base">
          {routes.map((route, i) => {
            if (
              route.permisson == userSlice?.roles[0].name ||
              route.name == "Dashboard"
            ) {
              return (
                <li
                  onClick={() => dispatch(toggleSidebar("close"))}
                  key={i}
                  className={
                    (url.includes(route.path)
                      ? "bg-[#EDFAFF]  rounded-xl text-primary dark:text-[#EDFAFF] dark:bg-[#282828] font-semibold"
                      : "text-secondary") + " max-w-[100%] pe-2 "
                  }
                >
                  <Link
                    to={route.path}
                    className="flex items-center gap-2 ps-4 py-3"
                  >
                    {route.icon !== "" ? (
                      <route.icon
                        fill={
                          url.includes(route.path) && theme == "dark"
                            ? "#EDFAFF"
                            : url.includes(route.path)
                            ? "#201AFF"
                            : "#A4A2FE"
                        }
                      />
                    ) : url.includes(route.path) ? (
                      <img src={route.active} />
                    ) : (
                      <img src={route.inActive} />
                    )}
                    {route.name}
                  </Link>
                </li>
              );
            }
          })}
          <li
            onClick={handleLogout}
            onMouseEnter={() => setFill("#fff")}
            onMouseLeave={() => setFill("#A4A2FE")}
            className="max-w-[100%] pe-2   hover:cursor-pointer rounded-xl hover:font-semibold"
          >
            <div className="flex items-center gap-2 ps-4 py-3  max-w-[100%] pe-2  text-secondary hover:text-white">
              <LogoutIcon fill={fill} />
              <p>Logout</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
