import React from "react";

type Props = {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name: string;
  type: string;
  label: string;
};

const Input: React.FC<Props> = ({ value, onChange, name, type, label }) => {
  return (
    <div className="flex w-full theme_text flex-col my-1 lg:gap-2 lg:my-2">
      <label htmlFor="email" className="text-[12px] lg:text-sm">
        {label}
      </label>
      <input
        required
        value={value}
        onChange={onChange}
        type={type}
        name={name}
        className=" h-[30px] lg:h-10 theme border-solid border-[1px] border-[#ABB3B7] outline-none focus:border-[#0D6EFD] rounded-[5px] px-4 w-full  text-xs"
      />
    </div>
  );
};

export default Input;
