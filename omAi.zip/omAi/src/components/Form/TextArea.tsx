import React from "react";

type Props = {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  name: string;
  label: string;
};

const TextArea: React.FC<Props> = ({ value, onChange, name, label }) => {
  return (
    <div className="flex w-full theme_text flex-col my-1 lg:gap-2 lg:my-2">
      <label htmlFor="email" className="text-[12px] lg:text-sm">
        {label}
      </label>
      <textarea
        required
        value={value}
        onChange={onChange}
        name={name}
        rows={10}
        className=" h-auto theme border-solid border-[1px] border-[#ABB3B7] outline-none focus:border-[#0D6EFD] rounded-[5px] px-4 w-full  text-xs"
      ></textarea>
    </div>
  );
};

export default TextArea;
