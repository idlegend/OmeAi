import { CgSpinner } from 'react-icons/cg';
const Loader = () => {
  return (
    <div className="bg-[#ffffff75] z-10 absolute flex justify-center items-center h-screen w-full">
      <CgSpinner className="text-primary w-10 h-10 animate-spin" />
    </div>
  );
};

export default Loader;
