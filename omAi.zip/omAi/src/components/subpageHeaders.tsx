import { useLocation, useParams } from "react-router";
import { routes } from "../routes";
import { Link } from "react-router-dom";
import { useAppDispatch } from "../utils/store";
import { clearData as clearTranslateData } from "../utils/features/translateSlice";
import { clearData as clearSubitileTranslateData } from "../utils/features/subtitleTranslationSlice";
import { clearData as clearSubitileGenerateData } from "../utils/features/subtitleGenerationSlice";

export const SubHeaders = () => {
  const dispatch = useAppDispatch();
  const { course_uuid } = useParams();
  const location = useLocation();
  const path = location.pathname;
  const route = routes.filter((route) => path.includes(route.path));
  const { name, path: routePath, subpages } = route[0];
  const sub = subpages?.filter((sub) => {
    if (course_uuid) {
      sub.path.includes(
        path.toLowerCase().split("/")[path.toLowerCase().split("/").length - 1]
      );
    }
    return course_uuid
      ? sub.path.includes(
          path.toLowerCase().split("/")[
            path.toLowerCase().split("/").length - 1
          ]
        )
      : path.includes(sub.path);
  });

  return (
    <p className="capitalize text-[12px] col-span-4 ml-1 md:ml-4 ">
      <Link
        onClick={() => {
          dispatch(clearTranslateData());
          dispatch(clearSubitileTranslateData());
          dispatch(clearSubitileGenerateData());
        }}
        to={routePath}
      >
        <span className="text-[#ABB3B7]">{name} </span>
      </Link>
      <span className="text-black"> / </span>
      <span className="text-black">{sub[0].name}</span>
    </p>
  );
};
