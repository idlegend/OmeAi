import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
} from 'recharts';

export const Chart = () => {
  const data = [
    {
      num: 100,
      name: 'Jan',
      pv: 50,
    },
    {
      num: 200,
      name: 'Feb',
      pv: 100,
    },
    {
      num: 300,
      name: 'Mar',
      pv: 50,
    },
    {
      num: 400,
      name: 'Apr',
      pv: 250,
    },
    {
      num: 500,
      name: 'May',
      pv: 40,
    },
    {
      num: 600,
      name: 'Jun',
      pv: 150,
    },
    {
      name: 'Jul',
      pv: 200,
    },
    {
      name: 'Aug',
      pv: 300,
    },
    {
      name: 'Sep',

      pv: 100,
    },
    {
      name: 'Oct',

      pv: 300,
    },
    {
      name: 'Nov',

      pv: 400,
    },
    {
      name: 'Dec',

      pv: 10,
    },
  ];
  return (
    <div className="w-full h-[245px] xl:h-[290px]">
      <ResponsiveContainer>
        <AreaChart
          data={data}
          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
              <stop offset="1%" stopColor="#201AFF" stopOpacity={0.5} />
              <stop offset="100%" stopColor="#201AFF" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis
            tickMargin={10}
            tickLine={false}
            axisLine={false}
            dataKey="name"
          />
          <YAxis
            tickMargin={10}
            tickLine={false}
            axisLine={false}
            dataKey="num"
          />
          <CartesianGrid vertical={false} strokeDasharray=" 1" />

          <Area
            type="monotone"
            dataKey="pv"
            stroke="#201AFF"
            fillOpacity={1}
            fill="url(#colorPv)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
