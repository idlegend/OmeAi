const Reference = () => {
  return <section>Reference</section>;
};

export default Reference;
