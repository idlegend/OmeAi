const Language = () => {
  return <section>Language</section>;
};

export default Language;
