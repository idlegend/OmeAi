import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { CgSpinner } from "react-icons/cg";
import {
  clearSuccess,
  updatePassword,
} from "../../utils/features/userSlice";
import { ellipse4, ellipse5, ellipse6 } from "../../assets/icons";
import { AuthImage } from "../../assets/images";
import { Icon } from "@iconify/react";

export const UpdatePassword = () => {
  const [type, setType] = useState("password");
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { loading, error, success, user } = useAppSelector((state) => state.user);
  interface formData {
    email: string;
    password: string;
    password_confirmation: string;
  }

  const [data, setData] = useState<formData>({
    email: user.email,
    password: "",
    password_confirmation: ""
  });


  useEffect(() => {
    if (success) {
      navigate("/signin");
      dispatch(clearSuccess());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [success]);

  const login = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();
    dispatch(updatePassword(data));
  };

  return (
    <div className="overflow-x-clip theme_text">
      <div className="w-[100vw] lg:min-h-[100vh] flex flex-col items-center justify-center space-y-[62px] py-4 lg:py-[51px]  theme">
        <div className="flex items-center  lg:justify-between flex-col lg:flex-row w-full lg:pl-[16px] lg:pr-[100px] space-y-[23px] lg:space-y-0 px-[22px] lg:px-0 ">
          <div className=" space-x-3  flex lg:hidden justify-center pt-[20px]">
            <img src={ellipse4} className="w-10" />
            <img src={ellipse5} className="w-[19px]" />
            <img src={ellipse6} className="w-[8px]" />
            <p className="text-base">Login</p>
            <img src={ellipse6} className="w-[8px]" />
            <img src={ellipse5} className="w-[19px]" />
            <img src={ellipse4} className="w-10" />
          </div>
          <div>
            <img
              src={AuthImage}
              alt="logo"
              className="lg:w-[450px] lg:h-[450px] w-[75px] h-[75px]"
            />
          </div>
          <div className="border border-[#ABB3B7] rounded-[20px] flex flex-col items-center  w-full h-full sm:w-[80vw] sm:h-full md:w-[700px] md:h-[510px] ">
            <div className=" space-x-3 w-full hidden lg:flex justify-center pt-[40px]">
              <img src={ellipse4} />
              <img src={ellipse5} />
              <img src={ellipse6} />
              <p className="text-[32px]">Update password</p>
              <img src={ellipse6} />
              <img src={ellipse5} />
              <img src={ellipse4} />
            </div>
            <div className="w-full h-full flex flex-col items-center justify-center  p-6 gap-8">
              <div className="w-full sm:w-[70%] md:w-[60%] pt-6 ">
                {error.errorString ? (
                  <div className="w-full bg-red-500 relative py-2 px-2 rounded">
                    <p className="theme_text">{error.errorString}</p>
                  </div>
                ) : null}
                {success ? (
                  <div className="w-full bg-green-500 relative py-2 px-2 rounded">
                    <p className="theme_text">Success... redirecting...</p>
                  </div>
                ) : null}
                <form className="w-full flex flex-col items-center theme_text ">
                  <div className="flex w-full flex-col my-1 lg:gap-2 lg:my-2">
                    <label htmlFor="email" className="text-[12px] lg:text-sm">
                      Email
                    </label>
                    <input
                      required
                      value={user.email}
                      onChange={() =>
                        setData({ ...data, email: user.email })
                      }
                      type="text"
                      disabled={true}
                      name="email"
                      className=" h-[30px] lg:h-10 theme border-solid border-[1px] border-[#ABB3B7] outline-none focus:border-[#0D6EFD] rounded-[5px] px-4 w-full  text-xs"
                    />
                  </div>
                  <div className="flex w-full flex-col my-1  lg:gap-2 lg:my-2">
                    <label
                      htmlFor="password"
                      className="text-[12px] lg:text-sm"
                    >
                      Password
                    </label>
                    <div className="w-full relative h-fit">
                      <div className="absolute h-full right-4 z-50 flex items-center ">
                        {type === "password" ? (
                          <Icon
                            icon="ion:eye-outline"
                            className="theme_text cursor-pointer"
                            onClick={() => setType("text")}
                          />
                        ) : (
                          <Icon
                            icon="ion:eye-off-outline"
                            className="theme_text cursor-pointer"
                            onClick={() => setType("password")}
                          />
                        )}
                      </div>
                      <input
                        required
                        value={data.password}
                        onChange={(e) =>
                          setData({ ...data, password: e.target.value })
                        }
                        type={type}
                        name="password"
                        className="h-[30px] lg:h-10  theme border-solid border-[1px] border-[#ABB3B7]  outline-none focus:border-[#0D6EFD] rounded-[5px] px-4 w-full text-xs"
                      />
                    </div>
                  </div>
                  <div className="flex w-full flex-col my-1  lg:gap-2 lg:my-2">
                    <label
                      htmlFor="password_confirmation"
                      className="text-[12px] lg:text-sm"
                    >
                      password confirmation
                    </label>
                    <div className="w-full relative h-fit">
                      <div className="absolute h-full right-4 z-50 flex items-center ">
                        {type === "password" ? (
                          <Icon
                            icon="ion:eye-outline"
                            className="theme_text cursor-pointer"
                            onClick={() => setType("text")}
                          />
                        ) : (
                          <Icon
                            icon="ion:eye-off-outline"
                            className="theme_text cursor-pointer"
                            onClick={() => setType("password")}
                          />
                        )}
                      </div>
                      <input
                        required
                        value={data.password_confirmation}
                        onChange={(e) =>
                          setData({ ...data, password_confirmation: e.target.value })
                        }
                        type={type}
                        name="password_confirmation"
                        className="h-[30px] lg:h-10  theme border-solid border-[1px] border-[#ABB3B7]  outline-none focus:border-[#0D6EFD] rounded-[5px] px-4 w-full text-xs"
                      />
                    </div>
                  </div>
        
                  <div className="w-full flex justify-center  mb-4 mx-2 mt-16">
                    <button
                      disabled={typeof loading == "boolean" ? loading : null}
                      onClick={(e) => login(e)}
                      type="submit"
                      className={`bg-[#201AFF] px-[28px] py-[6px] h-[40px] w-[100px] lg:w-auto lg:h-auto lg:px-[55px] lg:py-[9px] rounded theme_text text-center flex justify-center items-center text-[12px] lg:text-base ${
                        loading ? "bg-secondary" : ""
                      }`}
                    >
                      {loading ? (
                        <CgSpinner className="theme_text w-[25px] h-[25px] animate-spin" />
                      ) : (
                        "Update"
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdatePassword;
