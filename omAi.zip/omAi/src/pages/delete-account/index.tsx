import { Button, Input } from "@material-tailwind/react";
import axios from "axios";
import { useState, useEffect } from "react";
import { CgSpinner } from "react-icons/cg";

const DeleteAccount = () => {
  const [errors, setErrors] = useState<{
    success: string;
    errorString: string;
  }>({ success: "", errorString: "" });
  const [data, setData] = useState<{ email: string; message: string }>();
  const [loading, setLoading] = useState<boolean>();

  const deleteAccount = () => {
    setLoading(true);
    axios
      .post("/user/delete-account", data)
      .then((res) => {
        if (res.data.status == "success") {
          setData({ email: "", message: "" });
          setLoading(false);
          setErrors({
            errorString: "",
            success: "Successfully requested account delete.",
          });
        }
      })
      .catch((err) => {
        setErrors({ success: "", errorString: err.message });
        setLoading(false);
      });
  };
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      setErrors({ success: "", errorString: "" });
    }, 5000);

    return () => {
      clearTimeout(timeout);
    };
  }, [errors]);

  return (
    <section className="flex items-center justify-center bg-[#949090b7] h-screen ">
      <div className="bg-white rounded-md shadow-[0px_4px_8px_0px_rgba(0,0,0,0.10)] w-[90%] md:h-1/2 md:w-1/3 p-16 space-y-6 flex flex-col items-center">
        <p className="font-semibold text-center text-xl">
          Request Account Delete
        </p>
        <form className="space-y-6 flex flex-col items-center ">
          {errors && errors.errorString ? (
            <div className="w-full bg-red-500 relative py-2 px-2 rounded">
              <p className="text-white">{errors.errorString}</p>
            </div>
          ) : null}
          {errors && errors.success ? (
            <div className="w-full bg-green-500 relative py-2 px-2 rounded">
              <p className="text-white">{errors.success}</p>
            </div>
          ) : null}
          <div className="space-y-6">
            <Input
              value={data?.email}
              onChange={(e) => setData({ ...data, email: e.target.value })}
              crossOrigin="true"
              type="email"
              required
              label="User Email"
            />
            <Input
              value={data?.message}
              onChange={(e) => setData({ ...data, message: e.target.value })}
              crossOrigin="true"
              type="text"
              required
              label="Reason"
            />
          </div>
          <Button
            onClick={deleteAccount}
            disabled={loading || !data?.email || !data?.message}
            className="bg-primary capitalize"
          >
            {loading ? (
              <CgSpinner className="text-white w-[25px] h-[25px] animate-spin" />
            ) : (
              "Submit"
            )}
          </Button>
        </form>
      </div>
    </section>
  );
};

export default DeleteAccount;
