import { Textarea, Button } from "@material-tailwind/react";
import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { sendTranslateQuery } from "../../utils/features/translateSlice";
import { Outlet, useLocation } from "react-router";
import { CgSpinner } from "react-icons/cg";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import phone_icon from '../../assets/icons/phone-call.svg';
import email_icon from '../../assets/icons/email.svg';

const HelpAndSupport = () => {
    const dispatch = useAppDispatch();
    const { pathname: path } = useLocation();
    const [query, setQuery] = useState<{
        text?: string
    }>({});
    const { data, loading } = useAppSelector((state) => state.translate);
    // const navigate = useNavigate();

    useEffect(() => {
        
            setQuery({ text: ""});
    }, [data]);

    const handleSubmit = () => {
        dispatch(sendTranslateQuery(query));
    };

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const renderForm = () => (
        <div className="card-bg col-span-2 flex flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
            <div className="flex flex-col md:flex-row  justify-center items-center space-y-1 md:space-y-0 space-x-0 md:space-x-2 w-full ">
              
       
            </div>
            <div className="w-full">
                <Textarea
                    onChange={(e) => setQuery({ ...query, text: e.target.value })}
                    value={query?.text}
                    placeholder="Drop a message"
                />
            </div>
            <Button
                disabled={loading || !query?.text}
                onClick={handleSubmit}
                className="w-fit capitalize bg-primary"
            >
                {loading ? (
                    <CgSpinner className="w-6 h-5 animate-spin text-white" />
                ) : (
                    "Submit"
                )}
            </Button>
        </div>
    );

    const renderHelpandSupport = () => (
        <div className="card-bg col-span-2 flex flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
              <div className="flex w-full justify-center flex-col items-center mt-12 lg:mt-[60px] mb-[50px]">
                                <div className="flex gap-x-[38px] mt-[30px]">
                                    <a
                                        href="mailto:info@uniccongroup.com"
                                    >
                                        <div
                                            className="bg-[#201AFF] h-[48px] items-center flex p-[5px] rounded-[5px]"
                                        >
                                            <div className="flex flex-row items-center justify-between">

                                                <div> 
                                                     <img src={email_icon} alt="email-icon" className="" />
                                                </div>
                                                <div className="w-3"></div>
                                                <div className="text-white"> Email Us </div>
                                            </div>
                                        </div>
                                    </a>

                                    <div>
                                        <button
                                            className="h-[48px] items-center flex p-[5px] rounded-[5px] border border-[#201AFF]"
                                            onClick={handleClick}
                                        >

                                            <div className="flex flex-row items-center justify-between">

                                                <div><img src={phone_icon} alt="phone-icon" className="" /></div>
                                                <div className="w-3"></div>
                                                <div className="text-[#127FFF]"> Call Us </div>
                                            </div>
                                        </button>
                                        <Menu
                                            anchorEl={anchorEl}
                                            open={open}
                                            onClose={handleClose}
                                        >
                                            <MenuItem
                                                onClick={handleClose}
                                                component="a"
                                                href="tel:+2349137160848"
                                            >
                                                +2349137160848
                                            </MenuItem>
                                            <MenuItem
                                                onClick={handleClose}
                                                component="a"
                                                href="tel:+2349131573923"
                                            >
                                                +2349131573923
                                            </MenuItem>
                                            <MenuItem
                                                onClick={handleClose}
                                                component="a"
                                                href="tel:+447441426012"
                                            >
                                                +447441426012
                                            </MenuItem>
                                        </Menu>
                                    </div>
                                </div>
                            </div>
        </div>
    );

    return (
        <section className="section-grid-text-to-speech">
            {path === "/help-and-support" ? (
                <>
                    {renderForm()}
                    {renderHelpandSupport()}
                </>
            ) : (
                <Outlet />
            )}
        </section>
    );
};

export default HelpAndSupport;
