import Home from "./dashboard";
import Student from "./student";
import Reference from "./reference";
import Settings from "./settings";
import Report from "./report";
import Certificate from "./certificate";
import Language from "./language";
import { DigitalAssistant } from "./assistant";
import { Developer } from "./developer";
import { Translation, TranslationSuccess } from "./translation";
import { TextToSpeech, TextToSpeechSucess } from "./text-to-speech";
import { DigitalLiteracy } from "./literacy";
import {
  Translation as SubtitleTranslation,
  Generation,
  TranslationSuccess as SubtitleTranslationSuccess,
  GenerationSuccess,
} from "./subtitle";
import { Profile } from "./profile";
export * from "./FAQ/index";
import { HelpAndSupport } from "./help-and-support";

export {
  Profile,
  DigitalLiteracy,
  GenerationSuccess,
  TranslationSuccess,
  SubtitleTranslationSuccess,
  SubtitleTranslation,
  Generation,
  Translation,
  TextToSpeech,
  TextToSpeechSucess,
  Developer,
  DigitalAssistant,
  Home,
  Language,
  Certificate,
  Settings,
  Report,
  Reference,
  Student,
  HelpAndSupport
};
