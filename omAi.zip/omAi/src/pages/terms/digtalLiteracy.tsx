export const DigitalLiteracyTerms = () => {
  return (
    <section className="py-4 px-6 md:py-10 md:px-16 space-y-10">
      <p className="font-bold text-3xl">
        Terms and Conditions for Digital Literacy{" "}
      </p>
      <ol className="space-y-4">
        <li className="space-y-3">
          <p className="text-xl font-semibold"> 1. Agreement</p>
          <ul>
            <li>
              By using Digital Literacy (the "App"), downloading, or installing
              it, you consent to follow and be bound by these terms and
              conditions. Please don't use the app if you disagree with these
              terms.
            </li>
          </ul>
        </li>
        <li>
          <p className="text-xl font-semibold"> 2. License</p>
          <ul>
            <li>
              Digital Literacy gives you a revocable, non-exclusive, non
              transferable license to use the App on a mobile device that you
              own or control for personal, non-commercial uses. Reverse
              engineering, altering, distributing, or producing derivative works
              based on the App are prohibited.
            </li>
          </ul>{" "}
        </li>
        <li>
          {" "}
          <p className="text-xl font-semibold"> 3. User Account</p>
          <ul>
            <li>
              Some parts of the app might require you to register for an
              account. All activities that take place under your account and the
              confidentiality of the information associated with it are your
              responsibility.{" "}
            </li>
          </ul>
        </li>
        <li>
          {" "}
          <p className="text-xl font-semibold"> 4. Privacy </p>
          <ul>
            <li>
              Our Privacy Policy which describes our policies on the collecting
              and use of your personal information, also governs how you use the
              App.{" "}
            </li>
          </ul>
        </li>
        <li>
          <p className="text-xl font-semibold"> 5. Updates </p>
          <ul>
            <li>
              We may occasionally make updates for the app, and in order to take
              advantage of new features and enhancements, you are urged to keep
              your app updated.
            </li>
          </ul>
        </li>
        <li>
          {" "}
          <p className="text-xl font-semibold"> 6. Prohibited </p>
          <ul>
            <li>
              Conduct You consent to refrain from: Using the App for any
              illegitimate, unapproved, or immoral intent. Disregard any
              applicable laws, rules, or the rights of third parties. Try to
              access other user accounts or the App without authorization.
              Inflict harm, impede, or disrupt the App's functionality. Take
              part in any activity that places an excessive burden on our
              infrastructure.{" "}
            </li>
          </ul>
        </li>
        <li>
          <p className="text-xl font-semibold"> 7. Termination </p>
          <ul>
            <li>
              We reserve the right, at any time and without prior warning, to
              discontinue or suspend your use of the App for any reason,
              including breaking these terms and conditions.{" "}
            </li>
          </ul>{" "}
        </li>
        <li>
          <p className="text-xl font-semibold"> 8. Limitation of Liability </p>
          <ul>
            <li>
              Digital Literacy is given "as is" without any promises; hence, we
              disclaim all liability for any kind of damages—direct, indirect,
              special, incidental, or consequential.
            </li>
          </ul>
        </li>
        <li>
          <p className="text-xl font-semibold"> 9. Changes to Terms </p>
          <ul>
            <li>
              These Terms & Conditions are subject to change at any moment, at
              our discretion. You will be informed of any important changes. It
              is your duty to go over these terms from time to time.
            </li>
          </ul>
        </li>
        <li>
          <p className="text-xl font-semibold"> 10. Contact information </p>
          <ul>
            <li>
              Please email us at{" "}
              <a href="https://omeife.ai" className="text-primary">
                www.omeife.ai
              </a>{" "}
              if you have any queries or complaints regarding our terms and
              conditions.
            </li>
          </ul>{" "}
        </li>
      </ol>
    </section>
  );
};
