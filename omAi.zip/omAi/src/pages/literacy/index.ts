import DigitalLiteracy from "./digitalLiteracy";

export { DigitalLiteracy };
