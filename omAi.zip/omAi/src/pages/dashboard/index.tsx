import { Link } from "react-router-dom";
import {
  subtitleTranslation,
  subtitleGeneration,
  omeifeTranslate,
  assistant,
} from "../../assets/icons";
import { useAppSelector } from "../../utils/store";
import { Button } from "@material-tailwind/react";

const Home = () => {
  const { user } = useAppSelector((state) => state.user);
  const permission = user?.roles[0].name;

  return (
    <section className="section-grid dark:text-white">
      <div className="col-span-4">
        <p className="font-semibold capitalize"> Welcome, {user.first_name}.</p>
      </div>
      {permission == "Super Admin" ? (
        <div
          className={`${
            permission !== "Super Admin" ? "col-span-4" : "col-span-3"
          } gap-4 xl:gap-8 grid grid-cols-2 md:grid-cols-4 place-items-center  align-middle py-2 px-3 xl:py-4 xl:px-6  card-bg`}
        >
          <div className="border-r  space-y-4 xl:space-y-6  py-4 ">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Total Admin
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className="border-r  space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base  text-[#605C5C]">
              Total Organisation
            </h5>
            <h2 className=" text-3xl xl:text-4xl  text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className="border-r  space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Total Instructors
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className=" space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Total Students
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className="border-r  space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Total Courses
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className="border-r  space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Active Courses
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className="border-r  space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Pending Courses
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
          <div className=" space-y-4 xl:space-y-6  py-4">
            <h5 className="font-bold text-sm xl:text-base text-[#605C5C]">
              Total Lessons
            </h5>
            <h2 className=" text-3xl xl:text-4xl text-[#404043] font-bold">
              132
            </h2>
            <p className="text-[#605C5C] text-sm xl:text-base">
              <span className="text-[#67D677]">+12</span> This month
            </p>
          </div>
        </div>
      ) : (
        <div
          className={`${
            permission !== "Super Admin" ? "col-span-4" : "col-span-3"
          } gap-4 xl:gap-8 grid grid-cols-2 md:grid-cols-4 place-items-center  align-middle py-2 px-3 xl:py-4 xl:px-6  card-bg `}
        >
          <Link
            to={"/assistant"}
            className=" space-y-4 xl:space-y-6  py-4 cursor-pointer "
          >
            <img src={assistant} alt="" />
          </Link>
          <Link
            to={"/subtitle-generation"}
            className="  space-y-4 xl:space-y-6  py-4"
          >
            <img src={subtitleGeneration} alt="" />
          </Link>
          <Link to={"/translate"} className=" space-y-4 xl:space-y-6  py-4">
            <img src={omeifeTranslate} alt="" />
          </Link>
          <Link
            to={"/subtitle-translation"}
            className=" space-y-4 xl:space-y-6  py-4"
          >
            <img src={subtitleTranslation} alt="" />
          </Link>
        </div>
      )}
      {permission !== "Super Admin" && (
        <div className="card-bg col-span-4 grid md:place-items-center grid-cols-1 md:grid-cols-2 py-2 px-3 xl:py-4 xl:px-6 space-y-2 md:space-y-0  ">
          <Button className="bg-primary">
            <a
              href="https://apis.omeife.ai/storage/default/omeife-AI.apk"
              download={"Omeife AI"}
            >
              Download Omeife Ai App
            </a>
          </Button>
          <Button className="bg-primary">
            <a
              href="https://apis.omeife.ai/storage/default/omeife-digital-literacy.apk"
              download={"Omeife Digital Literacy"}
            >
              Download Digital Literacy App
            </a>
          </Button>
        </div>
      )}
    </section>
  );
};

export default Home;
