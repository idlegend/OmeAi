import { Select, Option, Textarea, Button } from "@material-tailwind/react";
import { transalteIcon } from "../../assets/icons";
import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { sendTranslateQuery } from "../../utils/features/translateSlice";
import { Outlet, useLocation, useNavigate } from "react-router";
import { CgSpinner } from "react-icons/cg";

const Translation = () => {
  const dispatch = useAppDispatch();
  const { pathname: path } = useLocation();
  const [query, setQuery] = useState<{
    text?: string;
    from?: string;
    to?: string;
  }>();
  const { data, loading } = useAppSelector((state) => state.translate);
  const navigate = useNavigate();

  useEffect(() => {
    if (data.translated) {
      navigate("/translate/success");
      setQuery({ text: "", from: "", to: "" });
    }
  }, [data]);

  const handleSubmit = () => {
    dispatch(sendTranslateQuery(query));
  };
  return (
    <section className="section-grid">
      {path == "/translate" ? (
        <div className="card-bg col-span-4 md:place-self-center md:w-[75%]  flex  flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
          <div className="flex flex-col md:flex-row  justify-center items-center space-y-1 md:space-y-0 space-x-0 md:space-x-2 w-full ">
            <Select
              onChange={(e) => setQuery({ ...query, from: e })}
              value={query?.from}
              label="From"
            >
              <Option value="english">English</Option>
              <Option value="hausa">Hausa</Option>
              <Option value="yoruba">Yoruba</Option>
              <Option value="igbo">Igbo</Option>
            </Select>
            <div>
              <img src={transalteIcon} className="w-10 h-10 md:w-28" />
            </div>
            <Select
              onChange={(e) => setQuery({ ...query, to: e })}
              value={query?.to}
              label="To"
            >
              <Option value="english">English</Option>
              <Option value="hausa">Hausa</Option>
              <Option value="yoruba">Yoruba</Option>
              <Option value="igbo">Igbo</Option>
            </Select>
          </div>
          <div className="w-full">
            <Textarea
              onChange={(e) => setQuery({ ...query, text: e.target.value })}
              value={query?.text}
              placeholder="Input text here"
            />
          </div>
          <Button
            disabled={loading || !query?.text || !query.from || !query.to}
            onClick={handleSubmit}
            className="w-fit capitalize bg-primary"
          >
            {loading ? (
              <CgSpinner className="w-6 h-5 animate-spin text-white" />
            ) : (
              "Translate"
            )}
          </Button>
        </div>
      ) : (
        <Outlet />
      )}
    </section>
  );
};

export default Translation;
