const Certificate = () => {
  return <section>Certificate</section>;
};

export default Certificate;
