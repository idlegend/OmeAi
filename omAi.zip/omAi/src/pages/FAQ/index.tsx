import React from "react";
import {
  Accordion,
  AccordionHeader,
  AccordionBody,
} from "@material-tailwind/react";

function Icon({ id, open }: { id: number; open: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="28"
      height="28"
      viewBox="0 0 38 38"
      fill="none"
      className={`${
        id === open ? "rotate-180" : "rotate-0"
      } ease-in-out duration-300  transition-all`}
    >
      <path
        d="M19.0013 23.7503L12.2832 17.0338L14.5236 14.7949L19.0013 19.2726L23.479 14.7949L25.7194 17.0338L19.0013 23.7518V23.7503Z"
        fill="black"
      />
    </svg>
  );
}

export const FAQ = () => {
  const [open, setOpen] = React.useState<number>(1);

  const handleOpen = (value: number) => setOpen(open === value ? 0 : value);

  return (
    <section className="flex items-center justify-center bg-[#949090b7] h-screen ">
      <div className="card-bg w-[90%] max-h-[90%]  overflow-y-auto md:w-1/2 p-4 md:p-6 lg:p-12 space-y-4 ">
        <p className="font-semibold text-center text-xl">
          Frequently Asked Questions
        </p>
        <Accordion open={open === 1} icon={<Icon id={1} open={open} />}>
          <AccordionHeader onClick={() => handleOpen(1)}>
            What is Omeife AI?
          </AccordionHeader>
          <AccordionBody>
            Omeife AI is a technology created by Uniccon Group of Companies to
            push the ideas, resources, values, history, and culture of the
            African continent to the world by first creating an enabling AI
            infrastructure that will propel the existing users, workforce, and
            Africans to achieve better and more efficient results with the help
            of AI.
          </AccordionBody>
        </Accordion>
        <Accordion open={open === 5} icon={<Icon id={5} open={open} />}>
          <AccordionHeader onClick={() => handleOpen(5)}>
            What is Omeife Digital Literacy Assistant?
          </AccordionHeader>
          <AccordionBody>
            Omeife AI's digital literacy assistant feature provides information
            on a variety of topics related to digital literacy. It can be a
            helpful tool for people who are looking for information or who want
            to learn more about digital literacy.
          </AccordionBody>
        </Accordion>
        <Accordion open={open === 2} icon={<Icon id={2} open={open} />}>
          <AccordionHeader onClick={() => handleOpen(2)}>
            What can Omeife AI do?
          </AccordionHeader>
          <AccordionBody>
            Omeife AI can provide translation services, subtitle translation and
            generation, knowledge assistant, summarisation, and video/audio
            translation.
          </AccordionBody>
        </Accordion>
     
        <Accordion open={open === 4} icon={<Icon id={4} open={open} />}>
          <AccordionHeader onClick={() => handleOpen(4)}>
            What languages can Omeife AI translate?
          </AccordionHeader>
          <AccordionBody>
            Omeife AI can translate from a source language to a target language.
            It can translate from languages such as Hausa, Yoruba, Hausa, Igbo,
            and Pidgin.
          </AccordionBody>
        </Accordion>
        <Accordion open={open === 3} icon={<Icon id={3} open={open} />}>
          <AccordionHeader onClick={() => handleOpen(3)}>
            What is the maximum file size of audio/video I can upload?
          </AccordionHeader>
          <AccordionBody>
            You can upload a file with maximum size of 20MB
          </AccordionBody>
        </Accordion>
      </div>
    </section>
  );
};
