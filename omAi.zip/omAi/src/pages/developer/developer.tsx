import { Button } from "@material-tailwind/react";
import { useEffect, useState } from "react";
import axios from "axios";
import Loader from "../../components/loader";
import { CgSpinner } from "react-icons/cg";
import { infoIcon } from "../../assets/icons";
Loader;

const Developer = () => {
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [value, setValue] = useState<string>("your auth token");

  const generateToken = async () => {
    setLoading(true);
    axios
      .get("/user/developer/generate-key")
      .then((res) => {
        // console.log(res.data);
        setLoading(false);
        setValue(res.data.data.key);
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    if (isCopied) {
      setTimeout(() => {
        setIsCopied(false);
      }, 5000);
    }
  }, [isCopied]);

  const handleCopy = () => {
    navigator.clipboard.writeText(value).then(() => {
      setIsCopied(true);
    });
  };
  return (
    <section className="section-grid">
      <div className="card-bg col-span-4 flex flex-col items-center space-y-6 px-2 md:px-4 py-2 md:py-6">
        <div className="flex flex-col items-center space-y-2">
          <p className="font-semibold text-center text-2xl md:text-3xl">
            Generate Your Authtoken
          </p>
          <p className="text-sm md:text-base">
            Use this to authenticate your requests.
          </p>
          <div className="text-sm md:text-base flex items-center space-x-2">
            <span>
              <img src={infoIcon} className="w-4 h-4 md:w-5 md:h-5" />
            </span>
            <p>Note: Copy and save your auth token </p>
          </div>
        </div>
        <div className="flex space-x-1 md:space-x-3  w-full md:w-1/2  h-fit  ">
          <input
            onClick={handleCopy}
            className="input-style w-[75%] md:w-[93%]"
            readOnly
            value={value}
          />
          {value !== "your auth token" ? (
            <Button
              onClick={handleCopy}
              size="sm"
              className={`${
                isCopied ? "bg-green-300" : "bg-primary"
              } flex capitalize items-center`}
            >
              <p>{isCopied ? "Copied" : "Copy"}</p>
            </Button>
          ) : (
            <Button
              onClick={generateToken}
              disabled={loading}
              size="sm"
              className="flex capitalize justify-center  items-center bg-primary"
            >
              {loading ? (
                <CgSpinner className="w-7 h-7 animate-spin text-white" />
              ) : (
                <p>Generate</p>
              )}
            </Button>
          )}
        </div>
      </div>
      <div className="card-bg col-span-4 space-y-3 px-2 md:px-4 py-2 md:py-6">
        <p>Access our documentation here:</p>

        <div>
          <a
            target="_blank"
            href="https://documenter.getpostman.com/view/25285261/2s9YJhvzEK"
          >
            <input
              readOnly
              type="text"
              className="input-style"
              value={
                "https://documenter.getpostman.com/view/25285261/2s9YJhvzEK"
              }
            />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Developer;
