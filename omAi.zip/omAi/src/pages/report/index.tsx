const Report = () => {
  return <section>Report</section>;
};

export default Report;
