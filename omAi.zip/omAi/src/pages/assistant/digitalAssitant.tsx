import { Button, Input } from "@material-tailwind/react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import {
  sendAssistantQuery,
  updateMessages,
} from "../../utils/features/assistantSlice";
import { useState, useEffect, useRef } from "react";
import { chatLogo } from "../../assets/icons";
import { CgSpinner } from "react-icons/cg";

const DigitalAssistant = () => {
  const { user } = useAppSelector((state) => state.user);
  const { messages, loading } = useAppSelector((state) => state.assistant);
  const dispatch = useAppDispatch();
  const [query, setQuery] = useState<string>();
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    dispatch(
      updateMessages({
        text: query,
        user: true,
        time: new Date().toLocaleTimeString(),
      })
    );
    dispatch(sendAssistantQuery(query));
    setQuery("");
  };

  return (
    <section className="section-grid">
      <div className="card-bg dark:text-black col-span-4 px-2 md:px-4 py-6 flex flex-col justify-between h-[80vh] ">
        <div className="h-[88%] overflow-y-auto p-1 md:p-2  ">
          <div
            className={`${
              !messages.length && "justify-center"
            } flex flex-col h-full  space-y-2 md:space-y-4`}
          >
            {messages.length ? (
              messages.map((message) => {
                return (
                  <>
                    <div
                      key={message.time}
                      className={`${
                        message.user ? "self-end" : ""
                      } flex items-start space-x-1 md:space-x-3 `}
                    >
                      {!message.user && (
                        <img
                          src={chatLogo}
                          alt=""
                          className=" w-8 h-8 md:w-12 md:h-12 rounded-full"
                        />
                      )}
                      <div
                        className={`${
                          !message.user ? "bg-teal-50" : "bg-teal-200"
                        } w-fit p-2 rounded-md max-w-[15rem] md:max-w-lg  space-y-2`}
                      >
                        <p className="text-sm md:text-base">{message.text}</p>
                        <p className="text-xs">{message.time}</p>
                      </div>
                      {message.user && (
                        <img
                          src={user.imageUrl}
                          alt=""
                          className=" w-8 h-8 md:w-12 md:h-12 rounded-full"
                        />
                      )}
                    </div>
                    <div ref={messagesEndRef} />
                  </>
                );
              })
            ) : (
              <div className="mx-auto dark:text-white">Type a question or request</div>
            )}
          </div>
        </div>
        <form
          onSubmit={(e) => handleSend(e)}
          className="flex space-x-1 md:space-x-3 w-full h-fit "
        >
          <Input
            crossOrigin="false"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a question or request"
            className="input-style "
          />
          <Button
            type="submit"
            className="bg-primary "
            disabled={!query}
            onClick={handleSend}
          >
            {loading ? (
              <CgSpinner className="w-6 h-5 animate-spin text-white" />
            ) : (
              "Send"
            )}
          </Button>
        </form>
      </div>
    </section>
  );
};

export default DigitalAssistant;
