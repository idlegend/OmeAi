import DigitalAssistant from "./digitalAssitant";

export {DigitalAssistant}