const Student = () => {
  return <section>Student</section>;
};

export default Student;
