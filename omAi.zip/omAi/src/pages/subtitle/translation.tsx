import { Select, Option,  Button } from "@material-tailwind/react";
import { uploadFile, changeFile } from "../../assets/icons";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { Outlet, useLocation, useNavigate } from "react-router";
import {
  sendSubtitleTranslateQuery,
  updateFileName,
} from "../../utils/features/subtitleTranslationSlice";
import { CgSpinner } from "react-icons/cg";

const Translation = () => {
  const { data, loading } = useAppSelector((state) => state.substitleTranslate);
  const dispatch = useAppDispatch();
  const { pathname: path } = useLocation();
  const navigate = useNavigate();
  const [query, setQuery] = useState<{
    file?: File;
    from?: string;
    to?: string;
  }>();
  const [file, setFile] = useState<File>();

  useEffect(() => {
    if (data.raw_srt) {
      navigate("/subtitle-translation/success");
      setQuery({ from: "", to: "" });
      setFile(undefined);
    }
  }, [data]);

  useEffect(() => {
    if (file) {
      dispatch(updateFileName(file.name.replace(/\..*$/, "")));
    }
  }, [file]);

  const handleSubmit = () => {
    dispatch(sendSubtitleTranslateQuery(query));
  };
  return (
    <section className="section-grid">
      {path == "/subtitle-translation" ? (
        <div className="card-bg col-span-4 md:place-self-center md:w-[75%]  flex  flex-col  space-y-4 px-2 md:px-4 py-2 md:py-6">
          <div className="space-y-3">
            <p>
              Upload subtitle file in SRT format{" "}
              <span className="text-red-700">*</span>{" "}
            </p>
            <div className="border rounded-md flex flex-col items-center p-6 relative space-y-2">
              {file ? (
                <img src={changeFile} alt="" />
              ) : (
                <img src={uploadFile} alt="" />
              )}
              <input
                onChange={(e) => {
                  setQuery({ ...query, file: e.target.files[0] });
                  setFile(e.target.files[0]);
                }}
                type="file"
                readOnly
                className="absolute right-0 left-0 top-0 bottom-0 opacity-0"
              />
              {file ? <div>{file.name}</div> : null}
            </div>
          </div>
          <div className="flex  flex-col space-y-4 items-center ">
            <div className="flex flex-col justify-center items-center space-y-3 w-full ">
              <div className="space-y-3 w-full">
                <p>
                  Select the base language of the file
                  <span className="text-red-700"> *</span>{" "}
                </p>
                <Select
                  onChange={(e) => setQuery({ ...query, from: e })}
                  value={query?.from}
                >
                  <Option value=""> </Option>
                  <Option value="english">English</Option>
                </Select>
              </div>
              <div className="space-y-3 w-full">
                <p>
                  Select the language the file will be converted to
                  <span className="text-red-700"> *</span>{" "}
                </p>
                <Select
                  onChange={(e) => setQuery({ ...query, to: e })}
                  value={query?.to}
                >
                  <Option value="english">English</Option>
                  <Option value="hausa">Hausa</Option>
                  <Option value="yoruba">Yoruba</Option>
                  <Option value="igbo">Igbo</Option>
                </Select>
              </div>
            </div>

            <Button
              disabled={loading || !query?.file || !query.from || !query.to}
              onClick={handleSubmit}
              className="w-fit capitalize bg-primary"
            >
              {loading ? (
                <CgSpinner className="w-7 h-7 animate-spin text-white" />
              ) : (
                "Convert"
              )}
            </Button>
          </div>
        </div>
      ) : (
        <Outlet />
      )}
    </section>
  );
};

export default Translation;
