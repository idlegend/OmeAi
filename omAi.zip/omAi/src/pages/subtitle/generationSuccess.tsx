import { useNavigate } from "react-router";
// import { copyIconWithBg } from "../../assets/icons";
import { SubHeaders } from "../../components";
import { useAppSelector } from "../../utils/store";
import { useEffect, useState } from "react";
import { copyIconWithBg, downloadIcon } from "../../assets/icons";

const GenerationSuccess = () => {
  const navigate = useNavigate();
  const { data } = useAppSelector((state) => state.subtitleGeneration);
  const [url, setUrl] = useState<string>();
  const [isCopied, setIsCopied] = useState<boolean>();
  const [srtText, setSrtText] = useState<string>();
  const [fileName, setFileName] = useState<string>();

  useEffect(() => {
    if (data.filename) {
      setSrtText(data.content);
    } else {
      navigate("/subtitle-generation");
    }
  }, []);

  useEffect(() => {
    if (srtText) {
      const content = srtText;
      setFileName(data.filename);
      const file = new Blob([content], { type: "text/plain" });
      setUrl(URL.createObjectURL(file));
    }
  }, [srtText]);

  const handleCopy = () => {
    navigator.clipboard.writeText(srtText).then(() => {
      setIsCopied(true);
    });
    setTimeout(() => {
      setIsCopied(false);
    }, 4000);
  };

  return (
    <>
      <SubHeaders />
      <div className="card-bg col-span-4 md:place-self-center md:w-[75%]  flex  flex-col items-center  space-y-16 px-2 md:px-4 py-2 md:py-6">
        <div className="space-y-3 w-full text-center">
          <p>Your subtitle is ready for download!</p>
          <textarea
            className="input-style !h-60"
            onChange={(e) => setSrtText(e.target.value)}
            value={srtText}
          />
        </div>
        <div className="flex flex-col space-y-2 items-center relative ">
          {isCopied && (
            <p className="font-semibold text-green-600 absolute -top-10 z-10 ">
              Copied!
            </p>
          )}
          <div className="flex space-x-4 items-center ">
            <a href={url} download={fileName}>
              <img src={downloadIcon} className="" />
            </a>
            <button onClick={handleCopy}>
              <img src={copyIconWithBg} className="" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default GenerationSuccess;
