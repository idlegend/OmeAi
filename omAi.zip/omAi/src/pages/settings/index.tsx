const Settings = () => {
  return <section>Settings</section>;
};

export default Settings;
