import { SubHeaders } from "../../components";
import { Button } from "@material-tailwind/react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { copyIconWithBg } from "../../assets/icons";
import { useNavigate } from "react-router";
import { clearData } from "../../utils/features/translateSlice";
import { useState, useEffect } from "react";

const TextToSpeechSucess = () => {
  const { data } = useAppSelector((state) => state.translate);
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [isCopied, setIsCopied] = useState<boolean>();

  useEffect(() => {
    if (!data.translated) {
      navigate("/translate");
    }
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(data.translated).then(() => {
      setIsCopied(true);
    });
    setTimeout(() => {
      setIsCopied(false);
    }, 4000);
  };
  return (
    <>
      <SubHeaders />
      <div className="card-bg col-span-4 md:place-self-center md:w-[75%]  flex  flex-col items-center  space-y-16 px-2 md:px-4 py-2 md:py-6">
        <div className="w-full">
          <textarea
            className="input-style h-[100px] "
            readOnly
            value={data.translated}
          />
        </div>
        <div className="flex flex-col space-y-2 items-center relative ">
          {isCopied && (
            <p className="font-semibold text-green-600 absolute -top-10 z-10 ">
              Copied!
            </p>
          )}
          <div className="flex space-x-4 items-center ">
            <button onClick={handleCopy}>
              <img src={copyIconWithBg} className="" />
            </button>
          </div>
        </div>

        <Button
          onClick={() => {
            dispatch(clearData());
            navigate("/translate");
          }}
          className="bg-primary"
        >
          Done
        </Button>
      </div>
    </>
  );
};

export default TextToSpeechSucess;
