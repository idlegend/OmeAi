import { Select, Option, Textarea, Button } from "@material-tailwind/react";
import { transalteIcon } from "../../assets/icons";
import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../utils/store";
import { sendTranslateQuery } from "../../utils/features/translateSlice";
import { Outlet, useLocation } from "react-router";
import { CgSpinner } from "react-icons/cg";
// import TextToSpeechSucess from "./textToSpeechSucess";
import AudioPlayer from "./AudioPlayer";
const TextToSpeech = () => {
    const dispatch = useAppDispatch();
    const { pathname: path } = useLocation();
    const [query, setQuery] = useState<{
        text?: string;
        from?: string;
        to?: string;
    }>({});
    const { data, loading } = useAppSelector((state) => state.translate);
    // const navigate = useNavigate();

    useEffect(() => {
        if (data.translated) {
            // navigate("/translate/success");
            setQuery({ text: "", from: "", to: "" });
        }
    }, [data]);

    const handleSubmit = () => {
        dispatch(sendTranslateQuery(query));
    };

    const renderTextToSpeechForm = () => (
        <div className="card-bg col-span-2 flex flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
            <div className="flex flex-col md:flex-row  justify-center items-center space-y-1 md:space-y-0 space-x-0 md:space-x-2 w-full ">
                <Select
                    onChange={(e) => setQuery({ ...query, from: e })}
                    value={query?.from}
                    label="From"
                >
                    <Option value="english">English</Option>
                    <Option value="hausa">Hausa</Option>
                    <Option value="yoruba">Yoruba</Option>
                    <Option value="igbo">Igbo</Option>
                </Select>
                <div>
                    <img src={transalteIcon} className="w-10 h-10 md:w-28" />
                </div>
                <Select
                    onChange={(e) => setQuery({ ...query, to: e })}
                    value={query?.to}
                    label="To"
                >
                    <Option value="english">English</Option>
                    <Option value="hausa">Hausa</Option>
                    <Option value="yoruba">Yoruba</Option>
                    <Option value="igbo">Igbo</Option>
                </Select>
            </div>
            <div className="w-full">
                <Textarea
                    onChange={(e) => setQuery({ ...query, text: e.target.value })}
                    value={query?.text}
                    placeholder="Place a text here"
                />
            </div>
            <Button
                disabled={loading || !query?.text || !query.from || !query.to}
                onClick={handleSubmit}
                className="w-fit capitalize bg-primary"
            >
                {loading ? (
                    <CgSpinner className="w-6 h-5 animate-spin text-white" />
                ) : (
                    "Convert"
                )}
            </Button>
        </div>
    );

    const renderOutComeForm = () => (
        <div className="card-bg col-span-2 flex flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
            <h1>Out Come</h1>
            <AudioPlayer />
        </div>
    );

    const renderNoOutComeForm = () => (
        <div className="card-bg col-span-2 flex flex-col items-center  space-y-4 px-2 md:px-4 py-2 md:py-6">
            <h1>Out Come</h1>
            <p>No Result Yet !!!</p>
        </div>
    );

    return (
        <section className="section-grid-text-to-speech">
            {path === "/text-to-speech" ? (
                <>
                    {renderTextToSpeechForm()}
                    {!data.translated ? renderOutComeForm() : renderNoOutComeForm()}
                </>
            ) : (
                <Outlet />
            )}
        </section>
    );
};

export default TextToSpeech;
