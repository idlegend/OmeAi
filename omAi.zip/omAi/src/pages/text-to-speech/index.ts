import TextToSpeech from "./textToSpeech";
import TextToSpeechSucess from "./textToSpeechSucess";
export{TextToSpeech, TextToSpeechSucess}