import React, { useEffect, useRef, useState } from 'react';
import WaveSurfer from 'wavesurfer.js';
import { FaPlay, FaPause } from "react-icons/fa";

const AudioPlayer: React.FC = () => {
  const waveformRef = useRef<HTMLDivElement | null>(null);
  const wavesurfer = useRef<WaveSurfer | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (waveformRef.current) {
      wavesurfer.current = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: '#4FD1C5',
        progressColor: '#009B86',
        cursorColor: '#4A5568',
        barWidth: 3,
        barRadius: 3,
        // responsive: true,
        height: 80,
        normalize: true,
        // partialRender: true,
      });

      wavesurfer.current.load('https://www.mfiles.co.uk/mp3-downloads/gs-cd-track2.mp3');

      wavesurfer.current.on('ready', () => {
        // Optionally, you can set other event listeners here
      });

      wavesurfer.current.on('finish', () => {
        setIsPlaying(false);
      });
    }

    return () => wavesurfer.current?.destroy();
  }, []);

  const handlePlayPause = () => {
    if (wavesurfer.current) {
      wavesurfer.current.playPause();
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="flex flex-col items-center p-4">
      <div className="mb-4 w-[300px] flex flex-row justify-between items-center ">
        <div>
      <button
        onClick={handlePlayPause}
        className="bg-[#201AFF] text-white p-2 rounded-full focus:outline-none"
      >
        {isPlaying ? <FaPause /> : <FaPlay />}
      </button>
      <div className='w-[50px]'></div>
      </div>
        <div ref={waveformRef} className="w-full h-24"></div>
      </div>
  
    </div>
  );
};

export default AudioPlayer;
