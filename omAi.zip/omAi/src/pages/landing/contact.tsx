import React, { useState } from "react";
import Heading from "../../components/common/Heading";
import Input from "../../components/Form/Input";
import TextArea from "../../components/Form/TextArea";
import Button from "../../components/common/Button";
import { toast } from "react-toastify";

const initState = {
  name: "",
  phone_no: "",
  email: "",
  subject: "",
  message: "",
};

const Contact: React.FC = () => {
  const [data, setData] = useState(initState);

  const handleChange = (
    e:
      | React.ChangeEvent<HTMLInputElement>
      | React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    setData(
      (prev) =>
        (prev = {
          ...prev,
          [e.target.name]: e.target.value,
        })
    );
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setData(initState);
    toast.success("We would be in touch shortly thank you.");
  };

  return (
    <div className="w-full h-full min-h-screen py-4 lg:py-10 flex flex-col gap-y-10">
      <Heading text="Contact Us" />
      <div className="w-full h-full bg-howitworksM_bg lg:bg-howitworks_bg  bg-no-repeat">
        <div className="contain w-full items-end md:items-center  grid grid-cols-1 gap-y-4 lg:grid-cols-2">
          <div className=" min-h-[335px] lg:h-0 "></div>
          <div className="h-full w-full order-last border rounded-[20px] p-6 lg:p-12 border-gray2 ">
            <form
              onSubmit={handleSubmit}
              className="flex flex-col items-center w-full justify-center gap-y-12"
            >
              <div className="flex w-full flex-col gap-y-4 ">
                <Input
                  label="Full Name"
                  name="name"
                  type="text"
                  value={data.name}
                  onChange={handleChange}
                />
                <Input
                  label="Email"
                  name="email"
                  type="email"
                  value={data.email}
                  onChange={handleChange}
                />
                <Input
                  label="Phone Number"
                  name="phone_no"
                  type="text"
                  value={data.phone_no}
                  onChange={handleChange}
                />
                <Input
                  label="Subject"
                  name="subject"
                  type="text"
                  value={data.subject}
                  onChange={handleChange}
                />
                <TextArea
                  label="Message"
                  name="message"
                  value={data.message}
                  onChange={handleChange}
                />
              </div>
              <Button type="submit" text="Submit" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
