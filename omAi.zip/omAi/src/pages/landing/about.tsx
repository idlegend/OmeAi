import React from "react";
import Heading from "../../components/common/Heading";
import { AbooutImage } from "../../assets/images";

const AboutUs: React.FC = () => {
  return (
    <div className="w-full h-full contain min-h-screen py-10 flex flex-col gap-y-10  ">
      <div className="w-full max-w-screen-lg mx-auto flex flex-col gap-y-6 ">
        <Heading text="About Us" />
      </div>
      <div className="grid  grid-cols-1 gap-y-10 lg:grid-cols-2 gap-0 items-center lg:py-12">
        <div className="space-y-6 lg:space-y-10">
          <h1 className="text-sm text-left lg:text-base leading-7 theme_text">
            The Omeife AI App is a revolutionary new AI-powered large language
            model that can generate text in a variety of styles and formats.
            Launched in October 2023 It is Africa’s first AI language model that
            can communicate accurately in multiple African dialects as well as
            Pidgin English, making it a powerful tool for communication and
            education across Africa. One of the remarkable features of Omeife AI
            is its language recognition and translation capabilities, which can
            assist users in translating text to widely spoken languages on the
            African continent such as French, Arabic, Yoruba, Hausa, Igbo and
            Swahili.
          </h1>
          <h1 className="text-sm text-left lg:text-base leading-7 theme_text">
            With its proficiency in African languages, Omeife AI becomes a
            versatile language companion that can understand and adapt to
            different accents, dialects, and regional variations. This feature
            makes it a valuable tool for users looking to learn African
            languages in a user-friendly manner or communicate to non-English
            speakers in their local dialects across Africa.
          </h1>
          <h1 className="text-sm text-left lg:text-base leading-7 theme_text">
            The Omeife AI also has other amazing features like, SRT subtitle
            translation, data summarization and knowledge assistant which can be
            used for research on various subjects like biology, business,
            marketing, finance, philosophy and so much more. Our vision is to
            make the lives of all African’s better with the power of AI
            technology. This vision drives our inclusive approach to developing
            technology making accessibility and useability the core of our
            philosophy in developing the Omeife AI
          </h1>
        </div>
        <div className="w-full flex  ">
          <div className="w-fit h-fit mx-auto">
            <img
              src={AbooutImage}
              className="w-[250px] h-[300px]  lg:w-[600px] lg:h-[680px] "
              alt="About Us"
            />
          </div>
        </div>
      </div>

      <div className="w-full max-w-screen-lg mx-auto flex flex-col gap-y-6 ">
        <Heading text="Mission" />
        <h1 className="text-sm text-center lg:text-base leading-7 lg:leading-9  theme_text">
          Our mission is to transform the digital economy of the African
          continent utilizing the power of AI.
        </h1>
      </div>
      <div className="w-full max-w-screen-lg mx-auto flex flex-col gap-y-6 ">
        <Heading text="Vision" />
        <h1 className="text-sm text-center lg:text-base leading-7 lg:leading-9 theme_text">
          Our vision is to make AI technology accessible to everyone on the
          African continent by imploring an inclusive approach towards
          developing our products. Making it possible for both the literate and
          the unlearned to benefit from AI technology.
        </h1>
      </div>
    </div>
  );
};

export default AboutUs;
