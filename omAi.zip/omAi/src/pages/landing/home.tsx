import React from "react";
import {
  appleImg,
  circularTextImg,
  googleImg,
  heroImg,
} from "../../assets/images";
import Button from "../../components/common/Button";
import {
  WhiteEllipsesLeft,
  WhiteEllipsesRight,
} from "../../assets/icons/Ellipses";
import CircularText from "../../assets/icons/CircularText";
import Heading from "../../components/common/Heading";
import { CarouselProvider } from "pure-react-carousel";
import Carousel from "../../components/Carousel";
import { Link, useNavigate } from "react-router-dom";

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="py-6 space-y-4 lg:space-y-11">
      {/* Hero */}
      <div className="min-h-[calc(100vh-80px)] w-full relative items-center grid gird-cols-1 gap-3 lg:grid-cols-2">
        <div>
          <div className="flex lg:hidden flex-col gap-y-10 items-center lg:items-start lg:gap-y-16">
            <div className="space-y-2 px-6 lg:px-0">
              <h1 className="text-2xl lg:text-5xl text-center lg:text-start font-bold font-sans theme_text lg:leading-[70px]  ">
                Welcome To <span className="clip_text">Omeife AI,</span> Virtual
                Assistant, Voice and Chat Bot !!!
              </h1>
              <h3 className="theme_text text-center lg:text-start text-xs lg:text-base ">
                Get to interact with Omeife AI and dive into an amazing world of
                knowledge exploitation with omeife.
              </h3>
            </div>
            <Button text="Get Started" action={() => navigate("/signin")} />
          </div>
        </div>
        <div>
          <img src={heroImg} alt="hero" />
        </div>
        <div className="absolute hidden lg:grid w-full contain h-full top-0 left-0 right-0 bottom-0 lg:items-center gap-x-24 grid-cols-1 lg:grid-cols-2 ">
          <div className="flex flex-col gap-y-10 items-center lg:items-start lg:gap-y-16">
            <div className="space-y-2 px-4 lg:px-0">
              <h1 className="text-2xl lg:text-5xl text-center lg:text-start font-bold font-sans theme_text lg:leading-[70px]  ">
                Welcome To <span className="clip_text">Omeife AI,</span> Virtual
                Assistant, Voice and Chat Bot !!!
              </h1>
              <h3 className="theme_text text-center lg:text-start text-xs lg:text-base ">
                Get to interact with Omeife AI and dive into an amazing world of
                knowledge exploitation with omeife.
              </h3>
            </div>
            <Button text="Get Started" />
          </div>
        </div>
      </div>
      {/* Download the App */}
      <div className="h-full py-24 bg-light-pattern-light dark:bg-light-pattern bg-no-repeat flex gap-y-16 flex-col bg-top download_app  ">
        <div className="w-full flex items-center justify-center gap-x-2 lg:gap-x-11">
          <WhiteEllipsesLeft />
          <h1 className="text-base lg:text-4xl font-bold text-white ">
            Download the App
          </h1>
          <WhiteEllipsesRight />
        </div>
        <div className="w-full flex items-center gap-x-6 lg:gap-x-12 justify-center">
          <Link
            to="https://apps.apple.com/ng/app/omeife-ai/id6469103139"
            target="_blank"
          >
            <img className="w-[125px] h-[40px] " src={appleImg} />
          </Link>
          <Link
            to="https://play.google.com/store/apps/details?id=com.uniccon.omeife_ai"
            target="_blank"
          >
            <img className="w-[125px] h-[40px] " src={googleImg} />
          </Link>
        </div>
        <div className="w-full flex justify-center items-center">
          <div className="w-fit h-fit  relative rounded-full">
            <div className="w-fit h-fit animate-spin-slow delay-1000 rounded-full">
              <CircularText />
            </div>
            <div className="absolute top-0 left-0 bottom-0 right-0 flex justify-center items-center">
              <img
                src={circularTextImg}
                width={80}
                height={75}
                alt="Circular Text Img"
              />
            </div>
          </div>
        </div>
      </div>
      {/* How it works */}
      <div className="w-full flex gap-y-6 flex-col">
        <Heading text="How It Works" />
        <div className="w-full h-full bg-howitworksM_bg lg:bg-howitworks_bg bg-no-repeat">
          <div className="contain min-h-[700px] md:min-h-[620px] items-end md:items-center  grid grid-cols-1 lg:grid-cols-7">
            <div className="col-span-3"></div>
            <div className="col-span-4 text-sm lg:text-lg theme_text flex flex-col gap-y-8 font-normal leading-7 lg:leading-10 order-last">
              <h1>
                The user-friendly interface of the Omeife AI app/web makes it
                accessible to a broad audience. It’s intuitive design empowers
                users to navigate seamlessly through the app, enhancing their
                experience and encouraging widespread adoption.
              </h1>
              <h1>
                To get started, download the{" "}
                <b>
                  <em>Mobile App</em>
                </b>
                , sign up for free within few minutes and enjoy the seamless
                features of Omeife AI. You can as well use your browser to sign
                up in the Web App for free in order to get started and explore
                Omeife AI unique features.
              </h1>
            </div>
          </div>
        </div>
      </div>
      {/* Features */}
      <div className="w-full h-full flex flex-col">
        <Heading text="Features" />
        <div className="h-full lg:bg-features_bg bg-right bg-no-repeat lg:py-12 ">
          <div className="h-full contain grid grid-cols-1 w-full lg:grid-cols-5 gap-4 lg:gap-24 py-6  justify-center items-center ">
            <div className="lg:hidden w-[calc(100vw-32px)] mx-auto h-full flex justify-center items-center ">
              <img src="/features_bg_m.svg" />
            </div>
            <div className="col-span-3">
              <div className="lg:text-base theme_text font-normal flex flex-col gap-y-8 text-sm leading-7  lg:leading-10">
                <h1>
                  At it’s core, the Omeife AI boasts unparalleled translation
                  capabilities, allowing users to seamlessly convert text from
                  one language to another with remarkable accuracy and speed.
                  This includes major world languages such as English, Pidgin,
                  Yoruba, Hausa,and Igbo offering a broad spectrum of linguistic
                  coverage for users worldwide with other amazing features.
                </h1>
                <h1>
                  Omeife AI is a bridge that brings people together, fostering
                  connections that transcend language barriers. In a world where
                  effective communication is paramount, the Omeife AI app stands
                  as a beacon of innovation, promoting inclusivity,
                  understanding, and collaboration on a global scale. Embrace
                  the future of communication with Omeife AI and embark on a
                  journey where language is no longer a barrier but a gateway to
                  a more interconnected world.
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Customer Reviews */}
      <div className="w-full  flex gap-y-6 lg:gap-y-16 flex-col">
        <Heading text="Customer’s Review" />
        <div className="contain flex justify-center items-center">
          <CarouselProvider
            infinite
            naturalSlideWidth={100}
            naturalSlideHeight={100}
            totalSlides={4}
            className="w-full max-w-screen-md overflow-x-hidden  h-auto  "
            interval={4000}
            isIntrinsicHeight
          >
            <Carousel />
          </CarouselProvider>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
