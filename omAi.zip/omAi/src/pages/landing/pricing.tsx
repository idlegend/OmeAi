import React from "react";
import Heading from "../../components/common/Heading";
import { PricingImage } from "../../assets/images";

const Pricing: React.FC = () => {
  return (
    <div className="w-full h-[calc(100vh-70px)] flex flex-col py-4 lg:py-0 lg:justify-center items-center gap-y-16 ">
      <Heading text="Pricing" />
      <img
        src={PricingImage}
        className="w-[750px] h-[500px] "
        alt="Coming soon"
      />
    </div>
  );
};

export default Pricing;
