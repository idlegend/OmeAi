import React from "react";
import Heading from "../../components/common/Heading";
import {
  Feature1,
  Feature2,
  Feature3,
  Feature4,
  Feature5,
  Feature6,
  Feature7,
  Feature8,
} from "../../assets/images";
import FeatureCard from "../../components/common/FeatureCard";

const Features: React.FC = () => {
  return (
    <div className="w-full contain py-4 lg:py-10 flex flex-col items-center gap-y-20 ">
      <div className="w-full flex flex-col items-center gap-y-8">
        <Heading text="Current Features" />
        <div className="w-full flex flex-col gap-y-6  max-w-screen-xl">
          <FeatureCard
            text="Knowledge Assistant"
            image={Feature1}
            description="The Omeife AI app can act as a knowledge assistant, providing information on a variety of topics like biology, business, 
                        marketing, finance, philosophy and so much more."
          />
          <FeatureCard
            text="Text Translation"
            image={Feature2}
            description="The Omeife AI app can translate text from one language to another, including local dialects and pidgin. This can be a 
valuable tool for people who need to communicate with people who speak different languages such as French, Arabic, 
Yoruba, Hausa, Igbo and Swahili."
          />
          <FeatureCard
            text="Subtitle Generation"
            image={Feature3}
            description="Our AI model can generate subtitles for your audios and videos."
          />
          <FeatureCard
            text="Subtitle Translation"
            image={Feature4}
            description="Translate audio/video subtitles between the languages we support."
          />
        </div>
      </div>

      <div className="w-full flex flex-col items-center gap-y-8">
        <Heading text="Future Features" />
        <div className="w-full flex flex-col gap-y-6  max-w-screen-xl">
          <FeatureCard
            text="Live Translation"
            image={Feature5}
            description="Our AI to translate live audio to any language the user chooses in real time."
          />
          <FeatureCard
            text="Location"
            image={Feature6}
            description="Implement maps in our local languages using our AI models."
          />
          <FeatureCard
            text="Identity Verification"
            image={Feature7}
            description="Create and deploy models for image matching, voice recognition and face recognition."
          />
          <FeatureCard
            text="Ometaverse"
            image={Feature8}
            description="Integrate virtual reality using UNICCON VR."
          />
        </div>
      </div>
    </div>
  );
};

export default Features;
