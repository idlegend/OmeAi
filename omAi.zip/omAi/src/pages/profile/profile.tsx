import { Button, Input } from "@material-tailwind/react";
import { changeFile, uploadFile } from "../../assets/icons";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../utils/store";

import { CgSpinner } from "react-icons/cg";
import { ProfileFormState, User } from "../../interfaces";
import {
  showConfirmModal,
  updateUserProfile,
} from "../../utils/features/profileSlice";

const Profile = () => {
  const dispatch = useAppDispatch();
  const [file, setFile] = useState<File>();
  const { loading, error } = useAppSelector((state) => state.profile);
  const userString = sessionStorage.getItem("user");
  const user: User = userString ? JSON.parse(userString) : null;
  const [userUpdate, setUserUpdate] = useState<ProfileFormState>();

  useEffect(() => {
    if (user.first_name) {
      setUserUpdate({
        ...userUpdate,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        phone_number: user.phone_number,
        image: user.imageUrl,
      });
    }
  }, []);

  return (
    <section className="section-grid">
      <div className="card-bg col-span-4 md:place-self-center md:w-[75%]  flex  flex-col items-center space-y-4 px-2 md:px-4 py-2 md:py-6">
        {error.errorString ? (
          <div className="w-full bg-red-500 relative py-2 px-2 rounded">
            <p className="text-white">{error.errorString}</p>
          </div>
        ) : null}
        <div className="space-y-3 w-full md:w-1/2">
          <p>
            Update your profile picture
            <span className="text-red-700">*</span>{" "}
          </p>
          <div className="border rounded-md flex flex-col items-center p-6 relative space-y-2">
            {userUpdate?.image ? (
              <img src={changeFile} alt="" />
            ) : (
              <img src={uploadFile} alt="" />
            )}
            <input
              accept="image/*"
              onChange={(e) => {
                if (e.target.files.length) {
                  setFile(e.target.files[0]);
                  setUserUpdate({ ...userUpdate, image: e.target.files[0] });
                }
              }}
              type="file"
              readOnly
              className="absolute right-0 left-0 top-0 bottom-0 opacity-0"
            />
            {file && typeof userUpdate?.image !== "string" ? (
              <div>
                <img
                  src={URL.createObjectURL(userUpdate.image)}
                  alt={userUpdate.first_name}
                  className="w-32 h-32"
                />
              </div>
            ) : null}
            {userUpdate?.image && typeof userUpdate?.image == "string" ? (
              <img
                src={userUpdate.image}
                alt={userUpdate.first_name}
                className="w-32 h-32"
              />
            ) : null}
          </div>
        </div>
        <div className="space-y-3  w-full md:w-1/2">
          <p>
            First Name
            <span className="text-red-700">*</span>{" "}
          </p>
          <Input
            value={userUpdate?.first_name}
            onChange={(e) => {
              setUserUpdate({ ...userUpdate, first_name: e.target.value });
            }}
            crossOrigin="false"
            type="text"
          />
        </div>
        <div className="space-y-3  w-full md:w-1/2">
          <p>
            Last Name
            <span className="text-red-700">*</span>{" "}
          </p>
          <Input
            onChange={(e) => {
              setUserUpdate({ ...userUpdate, last_name: e.target.value });
            }}
            value={userUpdate?.last_name}
            crossOrigin="false"
            type="text"
          />
        </div>
        <div className="space-y-3  w-full md:w-1/2">
          <p>
            Email
            <span className="text-red-700">*</span>{" "}
          </p>
          <Input
            onChange={(e) => {
              setUserUpdate({ ...userUpdate, email: e.target.value });
            }}
            value={userUpdate?.email}
            crossOrigin="false"
            type="text"
          />
        </div>
        <div className="space-y-3  w-full md:w-1/2">
          <p>
            Phone number
            <span className="text-red-700">*</span>{" "}
          </p>
          <Input
            onChange={(e) => {
              setUserUpdate({ ...userUpdate, phone_number: e.target.value });
            }}
            value={userUpdate?.phone_number}
            crossOrigin="false"
            type="text"
          />
        </div>
        <div className="flex justify-between w-full md:w-1/2 pt-14">
          <Button
            onClick={() =>
              dispatch(showConfirmModal({ show: true, content: "delete your account" }))
            }
            className="w-fit capitalize bg-red-600"
          >
            Delete Account
          </Button>
          <Button
            disabled={
              loading ||
              !userUpdate?.image ||
              !userUpdate?.phone_number ||
              !userUpdate?.first_name ||
              !userUpdate?.last_name ||
              !userUpdate?.email
            }
            onClick={() => {
              if (userUpdate.image == user.imageUrl) {
                dispatch(
                  updateUserProfile({
                    email: userUpdate.email,
                    phone_number: userUpdate?.phone_number,
                    first_name: userUpdate?.first_name,
                    last_name: userUpdate?.last_name,
                  })
                );
              } else {
                dispatch(updateUserProfile(userUpdate));
              }
            }}
            className="w-fit capitalize bg-primary"
          >
            {loading ? (
              <CgSpinner className="w-6 h-5 animate-spin text-white" />
            ) : (
              "Update"
            )}
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Profile;
